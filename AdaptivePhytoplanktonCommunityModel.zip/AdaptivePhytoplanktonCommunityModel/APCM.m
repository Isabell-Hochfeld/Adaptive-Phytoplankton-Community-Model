%% APCM.m
% Adaptive Phytoplankton Community Model (individual-based)
% Includes the life cycles of three phytoplankton taxa
% Dinoflagellates: vegetative cells and resting cysts
% Diatoms: vegetative cells and resting spores
% Cyanobacteria: vegetative cells, vegetative cells with heterocysts,
% akinetes
 
close all;
clearvars;

addpath(genpath('Functions'))
   
%% SET CONDITIONS
ref = 1;                          % Control/reference run? no = 0, yes = 1
Nyears = 100;                     % Number of simulated years
fileEnd = 0;                      % End of loaded file, to continue loaded file: fileEnd = months the file was run, to start new file: fileEnd = 0 
fileSave = 1;                     % Save output into file? yes = 1
saveStart = 120;                  % First save [months]
saveStep = 120;                   % Save interval [months]
saveEnd = Nyears*12;              % Last save [months]
filenumber = 1;                   % Number of output file
species = [1 1 1 1];              % [Dinoflagellates Diatoms Cyanobacteria Zooplankton]
mutation = [1 2];                 % Adaption of [Topt CellSize], turn off mutations in Topt: [0 2], cell size plasticity cannot be turned of; work in progress!
mutCya = 1;                       % Mutation of cyanobacteria? no = 0;
rsp = 0;                          % Resuspension from the sediment, on = 1
expProb = 1;                      % Exponential decrease of resuspension probability? yes = 1, otherwise: linear decrease
mC_temp = 0;                      % T-dependent mortality rate of dinoflagellate cysts? 1: yes

filename = 'Evaluation/Output_Files/CA1_1_1200.mat';      % For ref = 0: name of file to load
filename_save = 'Evaluation/Output_Files/CA_%d_%d.mat';   % Name to save output

%% PARAMETERS AND VARIABLES
%% Time
dt = 3600;                        % Time step [s]
secondsPerDay = 24*60*60;         % Seconds per day
secondsPerYear = 360*24*60*60;    % Seconds per year
itmax = Nyears*360*24;            % Maximum number of iterations
if fileEnd == 0                   % First iteration depending on fileEnd
    itStart = 1;
else
    itStart = fileEnd + 1;
end
timeStart = 0;                    % Start of the simulation
time = timeStart:itmax+timeStart; % Time vector (hours)
days = ceil((time+1)/24);         % Time vector (days)
years = floor((days-1)/360);      % Time vector (years)

yearPlot = ceil(Nyears-1);        % Year to plot (default: final year)
dayPlot = yearPlot*360;           % First day of the year to plot
months = 1:12000;                 % Month array to print to screen (progress of simulation)

%% Environmental forcing 
% Temperature during the seasonal cycle
% Fit to data from 2011 - 2021 from the Gulf of Finland
a1 = 10.0754;
a2 = 360*24;
a3 = -0.9138*pi;
a4 = 9.76275;
temp_2011_2020 = a1*(sin(2*pi*time(1:end-1)./a2 + 2*pi/a3)) + a4;

% Temperature increase of 0.03°C per year (IPCC scenario SSP3-7.0, Allan et al., 2021)
temp_increase = 0.03*time(1:end-1)/(360*24);

% Set temperature forcing
if ref == 0
    temp = temp_2011_2020 + temp_increase;
elseif ref == 1
    temp = temp_2011_2020;
end
temp = [nan temp];

% Irradiance
i1 = 142;                         % Mean light intensity [W m^-2] (Stramska & Zuzewicz, 2013)
i2 = 130;                         % Range of light intensity [W m^-2] (Stramska & Zuzewicz, 2013)

% Irradiance during the seasonal cycle (Stramska & Zuzewicz, 2013)
IL = i1 + i2 * cos(2*pi*(time(1:end-1)-180*24)/(360*24));
IL = [nan IL];

% Properties of sea water
Tf = -0.33;                       % Freezing point Gulf of Finland [°C] (Hinners et al., 2017)

%% PHYTOPLANKTON LIFE CYCLES
TV = temp(2);                     % Temperature to determine initial cell volume [°C]
mpa = 5*10^(-5);                  % Biomass per agent [mmol N]
meanCrit = 100;                   % Minimum cell number to calculate average traits
% Resuspension
if rsp == 1
    rspPerc = 0.3;                % Resuspension probability relative to burial probability
    tScale = 10;                  % Time scale of decrease in resuspension probability [yr]
    rspEnd = 120;                 % End of resuspension period [d]
    rspStart = 270;               % Start of resuspension period [d]
end

%% Dinoflagellates
% Parameters are for A. malmogiense
if species(1) == 1
    % Vegetative cells
    muMax1 = 0.35/secondsPerDay;      % Maximum growth rate [s^-1] (Hinners et al., 2017)
    kN1 = 0.3;                        % Half saturation constant for N [mmol N m^-3] (Hinners et al., 2019)
    Topt1 = 10.8;                     % Optimum growth temprature [°C] (Hinners et al., 2017)
    Tl1 = 7.22;                       % Width parameter of thermal reaction norm [°C] (Hinners et al., 2017)
    Tl2 = 6.03;                       % Width parameter of thermal reaction norm [°C] (Hinners et al., 2017)
    i3 = dt*0.0085/secondsPerDay;     % Imitial slope of limL [m^2 W^-1 h^-1] (Hinners et al., 2019)
    T_VD1 = 13.0;                     % T threshold for mortality [°C] (Hinners et al., 2019)
    T_VD2 = 2.0;                      % T slope for mortality [°C] (Hinners et al., 2019)
    mR11 = dt*0.005/secondsPerDay;    % Minimum mortality rate [h^-1] (Hinners et al., 2019)
    V15_1 = (4/3)*pi*(18.7/2)^3;      % Volume at 15°C [mu m^3] (Hinners et al., 2017)
    b15_1 = Volume2Mass(V15_1);       % Biomass at 15°C [mmol N]
    b01 = b15_1 - 0.025*b15_1*(TV-15);% Initial reference biomass [mmol N] 

    % Resting cysts
    Nin1 = 10^3;                      % Initial number of agents
    delta1 = dt*0.2/secondsPerYear;   % Burial probability [h^-1]
    mR12 = dt*0.0097/secondsPerDay... % T-independent cyst mortality [h^-1] based on (Hinners et al., 2019) 
        - delta1;                     
    if mC_temp == 0
        % Temperature-independent cyst mortality
        mPb12 = mR12*ones(size(time));   
    else
        % Temperature-dependent cyst mortality (Hinners et al., 2019)
        mPb12 = mR12*(1+0.5*temp_increase);
    end

    % Encystment
    T_VC1 = 6.0;                     % T threshold for transition from V to C [°C] (Hinners et al., 2017)
    T_VC2 = 1.6;                     % T slope for transition from V to C [°C] (Hinners et al., 2017)
    XC = 1.0;                        % Encystment factor (Hinners et al., 2017)
    tR1_12 = dt*0.02/secondsPerDay;  % Basic encystment rate [h^-1] (Hinners et al., 2017)

    % Germination
    gStart = 44;                     % Start of germination period [d] (Hinners et al., 2019)
    gEnd = 60;                       % End of germination period [d] (Hinners et al., 2019)
    tPb1_21 = dt*0.1/secondsPerDay;  % Germination probability per time step
                                     % based on a germination rate of 0.1 d^-1 (Hinners et al., 2017)

    % Flexible traits
    mTrait(1,1) = Topt1;             % Mean Topt for initial distribution
    mTrait(1,2) = b01;               % Mean reference cell biomass for initial distribution
    
    cpa1 = mpa/b01;                  % Cells per agent
end

%% Diatoms
% Parameters from Warns (2013) and Spilling (2011): Thalassiosira baltica
% Parameters from Hense & Beckmann (2015): arbitrary diatom species
% Cell volume from Atkinson et al. (2003): Thalassiosira weisflogii 
% (volume within the lower range of T. baltica (Olenoina et al., 2006))
if species(2) == 1
    % Vegetative cells
    muMax2 = 0.9/secondsPerDay;       % Maximum growth rate [s^-1] (Warns, 2013)
    kN2 = 1.0;                        % Half-saturation constant for N [mmol N m^-3] (Warns, 2013)
    Topt2 = 12.0;                     % Optimum growth temperature 12.0 [°C] (Spilling, 2011)
    theta1 = 7;                       % T decay scale below optimum [°C] (Hense & Beckmann, 2015)
    theta2 = 4;                       % T decay scale above optimum [°C] (Hense & Beckmann, 2015)
    kI = 33.6;                        % Light half-saturation constant [W m^-2] (Hense & Beckmann, 2015)
    mPb21 = dt*0.02/secondsPerDay;    % Mortality probability per time step (Warns, 2013)
    V15_2 = 1533;                     % Volume at 15°C [mu m^3], Thalassiosira weissflogii (Atkinson et al., 2003)
    b15_2 = Volume2Mass(V15_2);       % Biomass at 15°C [mmol N]
    b02 = b15_2 - 0.025*b15_2*(TV-15);% Initial reference cell biomass [mmol N]
    alpha2 = dt*0.15/secondsPerDay;   % Irradiance slope for T. baltica [m^2 W^-1 h^-1] (Warns, 2013)
    alpha2 = alpha2/10;               % Visually modified irradiance slope [m^2 W^-1 h^-1]

    % Spores
    Nin2 = 10^3;                      % Initial number of agents
    delta2 = dt*0.2/secondsPerYear;   % Burial probability [h^-1]
    mPb22 = dt*0.02/secondsPerDay...  % Mortality probabilty per time step based on (Warns, 2013)
        + dt*0.0029/secondsPerYear...
        - delta2;

    % Transition
    avTime2 = 5*24;                   % Time scale for average growth rate [h] (Warns, 2013)
    tR2_12 = dt*0.2/secondsPerDay;    % Maximum transition rate from P21 to P22 [h^-1] (Warns, 2013)
    tR2_21 = dt*0.2/secondsPerDay;    % Maximum transition rate from P22 to P21 [h^-2] (Warns, 2013)
    muCrit2 = dt*0.135/secondsPerDay; % Critical growth rate [h^-1] modified from Warns (2013)
    c20 = 1;                          % Constant (transition from P21 to P22) (Warns, 2013)
    c21 = 1;                          % Constant (transition from P22 to P21) (Warns, 2013)

    % Flexible traits
    mTrait(2,1) = Topt2;              % Mean Topt for initial distribution
    mTrait(2,2) = b02;                % Mean reference cell biomass for initial distribution
    
    cpa2 = mpa/b02;                   % Cells per agent
end

%% Cyanobacteria
% Cyanobacteria complex that represents the dominant N2-fixing genera in
% the Baltic Sea, Nodularia, Aphanizomenon, and Anabaena (Stal et al., 2003; Karlsson et al., 2005)
% Cell volume for Aphanizomenon flos-aquae (Foy, 1980)
% Cylindrical shape (Olenina et al., 2006)
if species(3) == 1
    % Vegetaive cells
    kN3 = 0.3;                        % Half saturation constant for N [mmol N m^-3] (Hense & Beckmann, 2006)
    VegHet = 4;                       % Growth factor between P31 and P32 (Hense & Beckmann, 2006)
    mPb31 = dt*0.013/secondsPerDay;   % Mortality probability per time step (Hense & Beckmann, 2010)
    alpha = 1.75*10^(-7);             % Initial slope of the PI-curve [m^2 W^-1 s^-1] (Hense & Beckmann, 2006)
    omega0 = 0.15/secondsPerDay;      % Reference growth per second (adapted) (Hense & Beckmann, 2010: 0.24)
    Topt3 = 28.5;                     % Optimum growth temperature (mean over Nodularia, Aphanizomenon, and Anabaena)
    r = 4.47/2;                       % Cell radius at 20°C [mu m] (Aphanizomenon flos-aquae, Foy, 1980)
    h = 4.96;                         % Cell height at 20°C [mu m] (Aphanizomenon flos-aquae, Foy, 1980)
    V20 = pi*r^2*h;                   % Volume at 20^C [mu m^3]
    V15_3 = V20 - 0.025*V20*(15-20);  % Volume at 15°C [mu m^3]        
    b15_3 = Volume2Mass(V15_3);       % Biomass at 15°C [mmol N]
    b03 = b15_3 - 0.025*b15_3*(TV-15);% Initial reference biomass [mmol N]

    % N2-fixing stage
    Emax = 1.0;                       % Maximum energy quota (Hense & Beckmann, 2006)
    omega_lc0 = 0.537/secondsPerDay;  % Constant light capture rate [s^-1]
    Eperc = 0.01/secondsPerDay;       % Factor growth rate dependence on light capture
    n = 10^2;                         % Exponent in energy limitation
    m = 3;                            % Factor between energy consumption of fixation and growth (Hense & Beckmann, 2006)
    mPb32 = dt*0.013/secondsPerDay;   % Mortality probability per time step (Hense & Beckmann, 2010)
    
    % Non-diazotrophic stage
    Nin3 = 10^3;                      % Initial number of agents
    delta3 = dt*0.2/secondsPerYear;   % Burial probability [h^-1]
    mPb33 = dt*0.013/secondsPerDay... % Mortality probability per time step based on (Hense & Beckmann, 2010)
        + dt*0.41/secondsPerYear...
        - delta3;                     
    VegRes = 10;                      % Nutrient uptake factor between P31 and P33 (Hense & Beckmann, 2006)
    
    % Transfer
    tPb3 = dt*2.5*10^(-6);            % Basic transition probability per time step (Hense & Beckmann, 2006)
    g3start = 149;                    % Start transfer RES to VEG [d]
    g3end = 180;                      % End transfer RES to VEG [d]
    muCrit3 = dt*0.35/secondsPerDay;  % Critical growth rate transfer RES to VEG [h^-1]
    muCrit31 = 1.95*muCrit3;          % Critical growth rate transfer VEG to RES [h^-1]
    muCrit32 = 1.95*muCrit3/VegHet;   % Critical growth rate transfer HET to RES [h^-1]
    avTime3 = 12;                     % Time scale for average growth rate [h] (Hense & Beckmann, 2010)
    if mutation(2) ~= 0
        ILTold = 0;                   % Temporary variable for temperature and light conditions
        epsilon = 1e-7;               % Constant 
    else
        muCrit3 = dt*0.052/secondsPerDay;
    end

    % Flexible traits
    mTrait(3,1) = Topt3;              % Mean Topt for initial distribution
    mTrait(3,2) = b03;                % Mean reference biomass for initial distribution
    
    cpa3 = mpa/b03;                   % Cells per agent
end

%% Flexible traits
mutTraits = length(nonzeros(mutation));  % Number of potentially flexible traits
numTraits = length(mutation);            % Number of flexible traits
mutPb(1) = cpa1*2.5e-3;                  % Mutation probability per division for dinoflagellates based on Lenski & Travisano (1994)
mutPb(2) = cpa2*2.5e-3;                  % Mutation probability per division for diatoms based on Lenski & Travisano (1994)
mutPb(3) = cpa3*2.5e-3;                  % Mutation probability per division for cyanobacteria based on Lenski & Travisano (1994)

% optimum growth temperature
dist(1) = 1;                             % distribution type (1: single value, 2: uniform, 3: normal)
sTrait(1:3,1) = 0.495;                   % standard deviation (STD) of initial distribution
sigma1 = 0.1;                            % Mutational step size dinoflagellates (Beckmann et al., 2019) 
sigma2 = 0.1;                            % Mutational step size diatoms (Beckmann et al., 2019)
sigma3 = 0.1;                            % Mutational step size cyanobacteria (Beckmann et al., 2019)

% Cell size
% Set indices for phytoplankton arrays
if mutation(1) ~= 0
    idxSize = 3;
else
    idxSize = 2;
end
dist(2) = 1;                            % Distribution type
sTrait(:,2) = 0;                        % Standard deviation

%% ZOOPLANKTON
Z0 = 1.0;                         % Initial zooplankton concentration [mmol N m^-3]
muZ = 2.25/secondsPerDay;         % Maximum zooplankton growth rate [s^-1] (Merico et al., 2014)
mZ = 0.2/secondsPerDay;           % Zooplankton mortality rate [s^-1] (Schartau & Oschlies, 2003)
metZ = 0.009/secondsPerDay;       % Excretion rate of zooplankton [s^-1] (Schartau & Oschlies, 2003)
beta = 0.75;                      % Assimilation efficiency (Schartau & Oschlies, 2003)
kP = 1.0;                         % Half saturation constant [mmol N m^-3] (Fasham & McKelvie, 1990)
pref1 = 1;                        % Grazing preference dinoflagellates
pref2 = 1;                        % Grazing preference diatoms
pref3 = 0;                        % Grazing preference cyanobacteria
type = 3;                         % Holling-type grazing function (I-IV)

%% Nurtient cycling
N0 = 0.0;                         % Initial nitrogen concentration [mm N m^-3]
rD = 0.1/secondsPerDay;           % Remineralization rate [s^-1]
sD = 0.097/secondsPerDay;         % Sinking of detritus [s^-1]

%% Preallocation
P = zeros(itmax,4);               % Total phytoplankton
Z = zeros(itmax,1);               % Total zooplankton
N = zeros(itmax,1);               % Nitrogen
D = zeros(itmax,1);               % Detritus

% Phytoplankton
% Dinoflagellates
if species(1) == 1    
    if mutation(2) ~= 0
        P11 = double.empty(0,mutTraits+2);% Vegetative dinoflagellates
        P12 = zeros(Nin1,mutTraits+2);    % Dinoflagellate cysts
    else
        P11 = double.empty(0,mutTraits+1);% Vegetative dinoflagellates
        P12 = zeros(Nin1,mutTraits+1);    % Dinoflagellate cysts
    end
    P12sed = double.empty(0,mutTraits+3); % Buried dinoflagellate cysts
    P1sum = zeros(itmax,2);               % Total dinoflagellates
end
% Diatoms
if species(2) == 1
    if mutation(2) ~= 0
        P21 = double.empty(0,mutTraits+2);% Vegetative diatoms
        P22 = zeros(Nin2,mutTraits+2);    % Diatom spores
    else
        P21 = double.empty(0,mutTraits+1);% Vegetative diatoms
        P22 = zeros(Nin2,mutTraits+1);    % Diatom spores
    end
    P22sed = double.empty(0,mutTraits+3); % Buried diatom spores
    P2sum = zeros(itmax,2);               % Total diatoms
    mu5d1 = zeros(avTime2,1);             % Growth rate array P21 (5 d)
    mu5d2 = zeros(avTime2,1);             % Growth rate array P22 (5 d)
end
% Cyanobacteria
if species(3) == 1
    if mutation(2) ~= 0
        P31 = double.empty(0,mutTraits+3);% Vegetative cyanobacteria
        P32 = double.empty(0,mutTraits+3);% Diazotrophic cyanobacteria
        P33 = zeros(Nin3,mutTraits+3);    % Cyanobacteria resting stage
    else
        P31 = double.empty(0,mutTraits+1);% Vegetative cyanobacteria
        P32 = double.empty(0,mutTraits+1);% Diazotrophic cyanobacteria
        P33 = zeros(Nin3,mutTraits+1);    % Cyanobacteria resting stage
    end
    P33sed = double.empty(0,mutTraits+4); % Buried akinetes
    P3sum = zeros(itmax,3);               % Total cyanobacteria
    mu12h_1 = zeros(avTime3,1);           % Growth rate array P31 (12 h)
    mu12h_2 = zeros(avTime3,1);           % Growth rate array P32 (12 h)
    mu12h_3 = zeros(avTime3,1);           % Growth rate array P33 (12 h)
end

% Flexible traits
numSpec = length(nonzeros(species(1:2))) + species(3)*2;
if mutTraits > 0
    if mutation(2) ~= 0        
        meanTrait = zeros(itmax+1,...
            numSpec,numTraits+3);           % array to save average trait values
        seasonalTrait = zeros(itmax+1, ...
            numSpec,5);                     % array to save average trait values of growing stages
    else
        meanTrait = zeros(itmax+1,...
            numSpec,numTraits);             % array to save average trait values
    end
end

% Save Topt
Topt_total = cell(12,3,Nyears);   % Distribution
mTopt_lc = zeros(itmax,6);        % Mean value for each life cycle stage

%% Initialization
% Flexible traits
mTopt_lc(:,:) = nan;
seasonalTrait(:,:,:) = nan;
meanTrait(:,:,:) = nan;

% Calculate initial trait distribution
count = 1;
if mutTraits > 0
    for iTrait = 1:numTraits
        if mutation(iTrait) ~= 0
            if species(1) == 1
                % Dinoflagellates
                P12(:,count+1) = iDist(dist(iTrait),mTrait(1,iTrait),...
                    sTrait(1,iTrait),Nin1);
                meanTrait(1,1,count) = mTrait(1,iTrait);
            end
            if species(2) == 1
                % Diatoms
                P22(:,count+1) = iDist(dist(iTrait),mTrait(2,iTrait),...
                    sTrait(2,iTrait),Nin2);
                meanTrait(1,2,count) = mTrait(2,iTrait);
            end
            if species(3) == 1
                % Cyanobacteria
                P33(:,count+1) = iDist(dist(iTrait),mTrait(3,iTrait),...
                    sTrait(3,iTrait),Nin3);
                meanTrait(1,3,count) = mTrait(3,iTrait);
            end
            count = count + 1;
        end
    end
end

% Create overlapping generations and initialize nitrogen cell quotas
if species(1) == 1
    % Dinoflagellate cysts
    if mutation(2) ~= 0
        % Flexile referece cell biomass
        % Initial biomass per dinoflagellate cyst [mmol N m^-3]
        P12(:,1) = P12(:,idxSize)+rand(Nin1,1).*P12(:,idxSize);
        % Convert initial biomass to volume
        V = Mass2Volume(P12(:,1));
        % Initial maximum cell quota [mmol N cell^-1] (Maranon et al., 2013)
        P12(:,idxSize+1) = 10^(-9)*0.0714*10^(-1.26)*V.^0.93;
    else
        % Constant reference cell biomass
        % Initial biomass per dinoflagellate cyst [mmol N m^-3]
        P12(:,1) = b01+rand(Nin1,1)*b01; 
    end
    P1sum(1,2) = sum(P12(:,1))*cpa1; % Initial total dinoflagellate biomass [mmol N m^-3]
    P(1,1) = P1sum(1,2);             % Initial total dinoflagellate biomass [mmol N m^-3]
end    
if species(2) == 1
    % Diatom spores
    if mutation(2) ~= 0
        % Flexile referece cell biomass
        % Initial biomass per diatom spore [mmol N m^-3]
        P22(:,1) = P22(:,idxSize)+rand(Nin2,1).*P22(:,idxSize);
        % Convert initial biomass to volume
        V = Mass2Volume(P22(:,1));
        % Initial maximum cell quota [mmol N cell^-1] (Maranon et al., 2013)
        P22(:,idxSize+1) = 10^(-9)*0.0714*10^(-1.26)*V.^0.93;
    else
        % Constant referece cell biomass
        % Initial biomass per diatom spore [mmol N m^-3]
        P22(:,1) = b02+rand(Nin2,1)*b02;  
    end
    P2sum(1,2) = sum(P22(:,1))*cpa2; % Initial total diatom biomass [mmol N m^-3]
    P(1,2) = P2sum(1,2);             % Initial total diatom biomass [mmol N m^-3]
    oldest21 = 1;                    % Index average growth rate VEG
    oldest22 = 1;                    % Index average growth rate RES
end  
if species(3) == 1
    % Cyanobacteria resting stage (akinetes)
    if mutation(2) ~= 0
        % Flexile referece cell biomass
        % Initial biomass per cyanobacteria spore [mmol N m^-3]
        P33(:,1) = P33(:,idxSize)+rand(Nin3,1).*P33(:,idxSize);
        % Convert initial biomass to volume
        V = Mass2Volume(P33(:,1));
        % Initial maximum cell quota [mmol N cell^-1] (Maranon et al., 2013)
        P33(:,idxSize+1) = 10^(-9)*0.0714*10^(-1.26)*V.^0.93;
        % Initial energy quota (Hense & Beckmann, 2006)
        P33(:,idxSize+2) = Emax;
    else
        % Constant referece cell biomass
        % Initial biomass per cyanobacteria akinete [mmol N m^-3]
        P33(:,1) = b03+rand(Nin3,1)*b03; 
    end
    P3sum(1,3) = sum(P33(:,1))*cpa3; % initial cyanobacteria biomass
    P(1,3) = P3sum(1,3);             % initial total cyanobacteria biomass [mmol N m^-3]
    oldest31 = 1;                    % index average growth rate VEG
    oldest32 = 1;                    % index average growth rate HET
    oldest33 = 1;                    % index average growth rate RES
end

% Nitrogen, total phytoplankton, and zooplankton
N(1) = N0;                           % Initial nitrogen concentration [mmol N m^-3]
P(1,4) = sum(P(1,1:3));              % Initial total phytoplankton biomass [mmol N m^-3]
if species(4) == 1
    Z(1) = Z0;                       % Initial zooplankton biomass [mmol N m^-3]
end

% Control variables
mCounter = fileEnd/(30*24);          % Month counter
iSave = 1;                           % Control variable for saving

%% In case of warming simulation, load variables
if ref == 0
    s = load(filename,'N','D','P','Z','P11',...
        'P12','P21','P22','P31','P32','P33','P12sed','P22sed','P33sed',...
        'P1sum','P2sum','P3sum','it','seasonalTrait','meanTrait',...
        'Cexp','CvsP','Topt_total','mTopt_lc');
    
    P11 = s.P11;
    P12 = s.P12;
    P21 = s.P21;
    P22 = s.P22;
    P31 = s.P31;
    P32 = s.P32;
    P33 = s.P33;

    P12sed = s.P12sed;
    P22sed = s.P22sed;
    P33sed = s.P33sed;    

    if fileEnd == 0    
        N(1) = s.N(end);
        D(1) = s.D(end);
        Z(1) = s.Z(end);   
        
        P1sum(1,:) = s.P1sum(end,:);
        P2sum(1,:) = s.P2sum(end,:);
        P3sum(1,:) = s.P3sum(end,:);
        
        P(1,:) = s.P(end,:);

        P12sed(:,end) = P12sed(:,end) - s.it - 1;
        P22sed(:,end) = P22sed(:,end) - s.it - 1;    
        P33sed(:,end) = P33sed(:,end) - s.it - 1;        
        
        seasonalTrait(1,:,:) = s.seasonalTrait(end,:,:);
        meanTrait(1,:,:) = s.meanTrait(end,:,:);
    else
        iSave = fileEnd/(10*12*30*24) + 1;
        N(1:fileEnd+1) = s.N(1:fileEnd+1);
        D(1:fileEnd+1) = s.D(1:fileEnd+1);
        Z(1:fileEnd+1) = s.Z(1:fileEnd+1);
        P(1:fileEnd+1,:) = s.P(1:fileEnd+1,:);
        
        P1sum(1:fileEnd+1,:) = s.P1sum(1:fileEnd+1,:);
        P2sum(1:fileEnd+1,:) = s.P2sum(1:fileEnd+1,:);
        P3sum(1:fileEnd+1,:) = s.P3sum(1:fileEnd+1,:);
                
        seasonalTrait(1:fileEnd+1,:,:) = s.seasonalTrait(1:fileEnd+1,:,:);
        meanTrait(1:fileEnd+1,:,:) = s.meanTrait(1:fileEnd+1,:,:);
        
        for iYear = 1:fileEnd/(12*30*24)
            for iMonth = 1:12
                for iSpec = 1:3
                    Topt_total{iMonth,iSpec,iYear} = s.Topt_total{iMonth,iSpec,iYear};
                end
            end
        end
        mTopt_lc(1:fileEnd,:) = s.mTopt_lc(1:fileEnd,:);
    end    
end


%% LOOP OVER TIME
for it = itStart:itmax
    
    % Current temperature
    T = temp(it+1);    
    
    %% DINOFLAGELLATES
    if species(1) == 1        
        %% Vegetative cells
        % Check if vegetative cells are present
        if isempty(P11)
            % Set nutrient uptake, mortality, and grazing to zero
            muDt(1) = 0;
            mP11 = 0;
            mC11 = 0;
            gZ11 = 0;            
            % Set growth-related variables to nan
            if mutation(2) ~= 0
                kN = nan;
                muMaxSat = nan;
            end
            b0 = nan;
            growth = nan;
        else
            % Check for flexible traits
            % Optimum temperature
            if mutation(1) ~= 0
                % Flexible
                Topt = P11(:,2);
            else
                % Constant
                Topt = ones(size(P11(:,1)))*Topt1;
            end
            % Reference cell biomass
            if mutation(2) ~= 0
                % Flexible
                % Calculate nitrogen uptake rate, kN, and growth rate
                % Saturated growth rate and kN for reference cell biomass
                b0 = P11(:,idxSize);
                [~,Qmax] = CellQuota(b0);
                [muMaxSat,~,kN] = maxRates3(b0,Qmax,N(it));
                % Actual growth rate and uptake rate for current cell biomass
                [muMax,rho,~] = maxRates3(P11(:,1),P11(:,idxSize+1),N(it));
                % Saturated growth rate for current cell biomass
                [~,Qmax] = CellQuota(P11(:,1));
                [muMaxSat2,~,~] = maxRates3(P11(:,1),Qmax,N(it));
            else
                % Constant
                b0 = b01*ones(size(P11(:,1)));
                muMax = dt*muMax1*N(it)/(N(it)+kN1);
            end
            % Temperature limitation (Hinners et al., 2017)
            limT = exp(-(T-Topt).^2./(Tl1-Tl2*sign(T-Topt)).^2);
            % Light limitation (Webb et al., 1974)
            if T < Tf
                limL = 0;
            else
                limL = 1 - exp((-i3*IL(it+1))./muMaxSat2);
            end
            % Growth of individual cells
            growth = muMax.*b0.*limT.*limL;
            P11(:,1) = P11(:,1) + growth;  
            % Nitrogen uptake
            if mutation(2) ~= 0
                % Flexible reference cell biomass
                % Update internal nitrogen quota
                P11(:,idxSize+1) = P11(:,idxSize+1) + rho - growth;
                % Correct for excess nutrient uptake
                idx = find(P11(:,idxSize+1) > Qmax);
                rho(idx) = rho(idx) - (P11(idx,idxSize+1) - Qmax(idx));
                P11(idx,idxSize+1) = Qmax(idx);
                % Calculate total nutrient uptake
                muDt(1) = sum(rho);
            else
                % Constant reference cell biomass
                muDt(1) = sum(growth);
            end
            % Cell division
            [P11] = CellDivision(P11,b0,mutation,mutPb(1),sigma1,idxSize,b15_1,T);
            % Grazing and mortality
            % Get internal nitrogen quota for mortality function
            if mutation(2) ~= 0
                Q = P11(:,idxSize+1);
            else
                Q = zeros(size(P11(:,1)));
            end
            % Total biomass P11
            C = sum(P11(:,1))*cpa1;
            % Grazing probability
            gPb11 = grazing(dt,pref1,muZ,Z(it),kP,C,type);
            % Mortality probability
            mPb11 = (1-mR11)*0.5*(1+tanh((T-T_VD1)/T_VD2)+mR11);
            % Calculate loss due to grazing and mortality
            [P11,~,mP11,mC11,gZ11] = mortality(P11,0,mPb11,0,gPb11,Q,it);
            % Encystment
            % Transfer from vegetative cells to cysts
            % Transfer probability (Hinners et al., 2019)
            tPb1_12 = tR1_12*XC*0.5*(1+tanh((T-T_VC1)/T_VC2));
            % Call transfer function
            [P11,P12] = transfer(P11,P12,tPb1_12);
            
            % Seasonal variation of biomass-related traits (vegetative cells only)
            if (mutation(2) ~= 0) && (length(P11) >= meanCrit)
                seasonalTrait(it+1,1,1) = mean(P11(:,idxSize));  % Reference cell biomass
                seasonalTrait(it+1,1,2) = mean(kN);              % Half saturation constant for nitrogen [mmol N m^-3]
                seasonalTrait(it+1,1,3) = mean(muMaxSat)*24;     % Saturated maximum growth rate [d^-1]
                seasonalTrait(it+1,1,4) = mean(growth./b0)*24;   % Actual growth rate [d^-1]
                seasonalTrait(it+1,1,5) = mean(P11(:,2));        % Optimum temperature [°C]
            end
            % Save optimum temperature for each life cycle stage
            if length(P11(:,1)) >= meanCrit                      
                mTopt_lc(it,1) = mean(P11(:,2));
            end
        end
        
        %% Resting cysts
        % Check if cysts are present
        if isempty(P12)
            % No: set mortality and grazing to zero
            mP12 = 0;
            mC12 = 0;
            gZ12 = 0;
        else
            % Yes: calculate loss (grazing, mortality, burial) and germination
            % Cyst loss (grazing, mortality, burial)
            % Get internal nitrogen quota for mortality function
            if mutation(2) ~= 0
                Q = P12(:,idxSize+1);
            else
                Q = zeros(size(P12(:,1)));
            end
            % Total biomass P12
            C = sum(P12(:,1))*cpa1;
            % Grazing probability
            gPb12 = grazing(dt,pref1,muZ,Z(it),kP,C,type);
            % Calculate loss due to grazing, mortality, and burial
            [P12,P12sed,mP12,mC12,gZ12] = mortality(P12,P12sed,mPb12(it),delta1,gPb12,Q,it);
            % Germination 
            if (gStart+360*years(it) < days(it)) && (days(it) < gEnd+360*years(it))
                % Call transfer function
                [P12,P11] = transfer(P12,P11,tPb1_21);
            end
        end
        
        % Resuspension
        if rsp == 1
            if (rspEnd+360*years(it) > days(it)) || (days(it) > rspStart+360*years(it))
                % Call resuspension function
                [P12,P12sed] = resuspension2(P12,P12sed,delta1*rspPerc,expProb,it,tScale);
            end
        end
        
        %% Total dinoflagellate biomass
        P1sum(it+1,1) = sum(P11(:,1))*cpa1;       % Vegetative dinoflagellates
        P1sum(it+1,2) = sum(P12(:,1))*cpa1;       % Cysts
        P(it+1,1) = P1sum(it+1,1)+P1sum(it+1,2);  % Total dinoflagellates
        
        %% Mean trait values (P11 and P12)
        % Optimum temperature and reference cell biomass
        count = 1;
        for iTrait = 1:numTraits
            if mutation(iTrait) ~= 0
                meanTrait(it+1,1,count) = (sum(P11(:,count+1))+...
                    sum(P12(:,count+1)))/(length(P11(:,1))+length(P12(:,1)));
                count = count + 1;
            end
        end
        % Cell size-related traits
        if mutation(2) ~= 0
            meanTrait(it+1,1,count) = mean(kN);                % Half saturation constant for nitrogen [mmol N m^-3]
            meanTrait(it+1,1,count+1) = mean(muMaxSat)*24;     % Saturated maximum growth rate [d^-1]
            meanTrait(it+1,1,count+2) = mean(growth./b0)*24;   % Actual growth rate [d^-1]
        end
        % Save optimum temperature for each life cycle stage
        if length(P12(:,1)) >= meanCrit
            mTopt_lc(it,2) = mean(P12(:,2));
        end
    else
        % If no dinoflagellates are simulated, set the corresponding parameters to zero
        cpa1 = 0;
        muDt(1) = 0;
        mP11 = 0;
        mP12 = 0;
        mC11 = 0;
        mC12 = 0;
        gZ11 = 0;
        gZ12 = 0;
    end
    
    %% DIATOMS
    if species(2) == 1
        %% Vegetative cells
        % Nutrient limitation (Michaelis-Menten function)
        limN = N(it)./(N(it)+kN2);
        % Check if vegetative cells are present
        if isempty(P21)
            % Set nutrient uptake, mortality, and grazing to zero
            muDt(2) = 0;
            mP21 = 0;
            mC21 = 0;
            gZ21 = 0;
            % Set growth rate array to zero
            mu5d1 = zeros(avTime2,1);
            % Set growth-related variables to nan
            if mutation(2) ~=0
                kN = nan;
                muMaxSat = nan;
            end
            b0 = nan;
            growth = nan;
        else   
            % Chek for flexible traits
            % Reference cell biomass
            if mutation(2) ~= 0
                % Flexible
                % Calculate nitrogen uptake rate, kN, and growth rate
                % Saturated growth rate and kN or reference cell biomass
                b0 = P21(:,idxSize);
                [~,Qmax] = CellQuota(b0);
                [muMaxSat,~,kN] = maxRates3(b0,Qmax,N(it));
                % Actual growth rate and uptake rate for current cell biomass
                [muMax,rho,~] = maxRates3(P21(:,1),P21(:,idxSize+1),N(it));
                [~,Qmax] = CellQuota(P21(:,1));
            else
                % Constant
                b0 = b02*ones(size(P21(:,1)));
                muMax = dt*muMax2*limN;
            end
            % Temperature limitation (Hense & Beckmann, 2015)
            limT = limTDia(P21,P22,T,theta1,theta2,1,mutation,Topt2);
            % Light limitation (Warns, 2013)
            limL = 1 - exp((-alpha2*IL(it+1))./muMaxSat);           
            % Growth of individual cells
            growth = muMax.*b0.*limT.*limL;  
            P21(:,1) = P21(:,1) + growth;  
            % Nitrogen uptake
            if mutation(2) ~= 0
                % Flexible reference cell biomass
                % Update internal nitrogen quota [mmol N cell^-1]
                P21(:,idxSize+1) = P21(:,idxSize+1) + rho - growth;
                % Account for excess uptake
                idx = find(P21(:,idxSize+1) > Qmax);
                rho(idx) = rho(idx) - (P21(idx,idxSize+1) - Qmax(idx));
                P21(idx,idxSize+1) = Qmax(idx);
                % Calculate total nitrogen uptake [mmol N]
                muDt(2) = sum(rho);
            else
                % Constant reference cell biomass
                muDt(2) = sum(growth);  
            end
            % Cell division
            [P21] = CellDivision(P21,b0,mutation,mutPb(2),sigma2,idxSize,b15_2,T);   
            % Loss due to grazing and mortality
            % Get internal nitrogen quota for mortality function
            if mutation(2) ~= 0
                Q = P21(:,idxSize+1);
            else
                Q = zeros(size(P21(:,1)));
            end
            % Total biomass of P21
            C = sum(P21(:,1))*cpa2;
            % Grazing probability
            gPb21 = grazing(dt,pref2,muZ,Z(it),kP,C,type);
            % Calculate loss due to grazing and mortality
            [P21,~,mP21,mC21,gZ21] = mortality(P21,0,mPb21,0,gPb21,Q,it);
            % Transfer to P22
            % Mean relative growtn rate for current time step
            mu5d1(oldest21) = mean(muMax.*limT.*limL);
            oldest21 = avIdx(oldest21,avTime2);
            if length(nonzeros(mu5d1)) == avTime2
                % Mean relative growth rate over 5 days
                muMean = mean(mu5d1);
                % Transfer from vegetative cells to spores
                if muMean < muCrit2
                    % Transfer probability (Warns, 2013)
                    tPb2_21 = tR2_12*0.5*(1-tanh(c20*(muMean-muCrit2)));
                    % Call transfer function
                    [P21,P22] = transfer(P21,P22,tPb2_21);
                end
            end
            % Seasonal variation of biomass-related traits (vegetative cells only)
            if (mutation(2) ~= 0) && (length(P21) >= meanCrit)
                seasonalTrait(it+1,2,1) = mean(P21(:,idxSize));  % Reference cell biomass [mmol N]
                seasonalTrait(it+1,2,2) = mean(kN);              % Half saturation constant for nitrogen [mmol N m^-3]
                seasonalTrait(it+1,2,3) = mean(muMaxSat)*24;     % Saturated maximum growth rate [d^-1]
                seasonalTrait(it+1,2,4) = mean(growth./b0)*24;   % Actual growth rate [d^-1]
                seasonalTrait(it+1,2,5) = mean(P21(:,2));        % Optimum temperature [°C]
            end
            % Save optimum temperature for each life cycle stage
            if length(P21(:,1)) >= meanCrit
                mTopt_lc(it,3) = mean(P21(:,2));
            end
        end

        %% Resting spores  
        % Check if spores are present
        if isempty(P22)
            % Set mortality and grazing to zero
            mP22 = 0;
            mC22 = 0;
            gZ22 = 0;
            % Set growth rate array to zero
            mu5d2 = zeros(avTime2,1);
        else
            % Caluclate loss (grazing, mortality, burial) and transfer to P21
            % Spore grazing, mortality, and burial
            % Get internal nitrogen quota for mortality function
            if mutation(2) ~= 0
                Q = P22(:,idxSize+1);
            else
                Q = zeros(size(P22(:,1)));
            end
            % Total biomass of P22
            C = sum(P22(:,1))*cpa2;
            % Grazing probability
            gPb22 = grazing(dt,pref2,muZ,Z(it),kP,C,type);
            % Calculate loss due to grazing, mortality, and burial
            [P22,P22sed,mP22,mC22,gZ22] = mortality(P22,P22sed,mPb22,delta2,gPb22,Q,it);
            % Transfer to P21
            % Calculate mean relative growth rate over 5 days
            % Maximum growth rate for current time step
            if mutation(2) ~= 0
                % Flexible reference cell biomass
                [~,Qmax] = CellQuota(P22(:,idxSize));
                [muMax,rho,~] = maxRates3(P22(:,1),P22(:,idxSize+1),N(it));
                [muMaxSat,~,~] = maxRates3(P22(:,idxSize),Qmax,N(it));
            else
                % Constant reference cell biomass
                muMax = dt*muMax2*N(it)/(N(it)+kN2);
            end
            % Temperature limitation (Hense & Beckmann, 2015)
            limT = limTDia(P21,P22,T,theta1,theta2,2,mutation,Topt2);
            % Light limitation (Warns, 2013)
            limL = 1 - exp((-alpha2*IL(it+1))./muMaxSat);            
            % Realized relative growth rate for current time step
            mu5d2(oldest22) = mean(muMax.*limT.*limL);
            oldest22 = avIdx(oldest22,avTime2);
            if length(nonzeros(mu5d2)) == avTime2     
                % Relative growth rate over 5 days
                muMean = mean(mu5d2);
                % Transfer from spores to vegetative cells
                if muMean >= muCrit2
                    % Transfer probability (Warns, 2013)
                    tPb2_22 = tR2_21*(-0.5*(1-tanh(c21*(muMean-muCrit2)))+1); 
                    % Call transfer function
                    [P22,P21] = transfer(P22,P21,tPb2_22);
                end
            end
        end
        % Resuspension
        if rsp == 1
            if (rspEnd+360*years(it) > days(it)) || (days(it) > rspStart+360*years(it))
                % Call resuspension function
                [P22,P22sed] = resuspension2(P22,P22sed,delta2*rspPerc,expProb,it,tScale);
            end
        end
        
        %% Total diatom biomass
        P2sum(it+1,1) = sum(P21(:,1))*cpa2;      % Vegetative diatoms
        P2sum(it+1,2) = sum(P22(:,1))*cpa2;      % Spores
        P(it+1,2) = P2sum(it+1,1)+P2sum(it+1,2); % Total diatoms
        
        %% Mean trait values (P21 and P22)
        % Optimum temperature and reference cell biomass
        count = 1;
        for iTrait = 1:numTraits
            if mutation(iTrait) ~= 0
                meanTrait(it+1,2,count) = (sum(P21(:,count+1))+...
                    sum(P22(:,count+1)))/(length(P21(:,1))+length(P22(:,1)));
                count = count + 1;
            end
        end
        % Cell size-related traits
        if mutation(2) ~= 0
            meanTrait(it+1,2,count) = mean(kN);              % Half saturation constant for nitrogen [mmol N m^-3]
            meanTrait(it+1,2,count+1) = mean(muMaxSat)*24;   % Saturated maximum growth rate [d^-1]
            meanTrait(it+1,2,count+2) = mean(growth./b0)*24; % Actual growth rate [d^-1]
        end
        % Save optimum temperature for each life cycle stage
        if length(P22(:,1)) >= meanCrit
            mTopt_lc(it,4) = mean(P22(:,2));
        end    
    else
        % If no diatoms are simulated, set the corresponding parameters to zero
        cpa2 = 0;
        muDt(2) = 0;
        mP21 = 0;
        mP22 = 0;
        mC21 = 0;
        mC22 = 0;
        gZ21 = 0;
        gZ22 = 0;
    end
    
    %% CYANOBACTERIA
    if species(3) == 1
        % Temperature and irradiance conditions (for transfer)
        ILT = IL(it+1) * T;
        % Check if cyanobacterial thermal adaptation is enabled or disabled
        if (mutation(1) == 1) && (mutCya == 0)
            mutTmp = 1;
            mutation(1) = 0;
        end        
        
        %% Vegetative growth
        % Check if vegetative cells are present
        if isempty(P31)     
            % Set nutrient uptake, mortality, and grazing
            muDt(3) = 0;     % Nutrient uptake    
            mP31 = 0;        % Mortality
            mC31 = 0;        % Carbon content of dead cells
            gZ31 = 0;        % Grazing loss
            % Set growth array rate to zeros
            mu12h_1 = zeros(avTime3,1);
            % Set growth-related variables to nan
            growth1 = nan;
            b01 = nan;
            if mutation(2) ~= 0
                kN31 = nan;
                muMaxSat31 = nan;
            end
        else
            % Check for adaptive traits
            % Optimum growth temperature
            if mutation(1) ~= 0
                % Flexible
                T3 = P31(:,2) - 16.43;
            else
                % Constant
                T3 = ones(size(P31(:,1)))*Topt3 - 16.43;
            end
            % Reference cell biomass
            if mutation(2) ~= 0
                % Flexible reference cell biomass
                % Actual cell biomass
                b = P31(:,1);
                % Reference cell biomass
                b01 = P31(:,idxSize);
                % Traits depending on reference biomass
                [~,Qmax] = CellQuota(b01);
                [muMaxSat31,~,kN31] = maxRates3(b01,Qmax,N(it));
                % Traits depending on actual cell biomass
                % Nutrient limited growth
                [muMax,rho,kN] = maxRates3(b,P31(:,idxSize+1),N(it));
                muMax = muMax/3600;
                % Nutrient saturated growth
                [Qmin,Qmax] = CellQuota(b);
                [muMaxSat1,~,~] = maxRates3(b,Qmax,N(it));
                muMaxSat1 = muMaxSat1/3600;
            else
                % Constant reference cell biomass
                b01 = b03*ones(size(P31(:,1)));
                muMax = omega0;
                muMaxSat1 = omega0;
                kN = kN3;
            end
            % Nutrient limitation (Hense & Beckmann, 2006)
            limN = N(it)./(N(it)+kN);
            % Temperature limitation (Hense & Beckmann, 2006)
            limT = muMax.*(0.022+1./(0.25+exp(3./(T-T3) ...
                -0.5)+exp(-(500./(T-T3)-25))));
            omega_lc = 5.*muMaxSat1.*(0.022+1./(0.25+exp(3./(T-T3) ...
                -0.5)+exp(-(500./(T-T3)-25))));
            % Light limitation (Beckmann & Hense, 2004)
            limL = (alpha*IL(it+1))./sqrt(omega_lc.^2+alpha^2*IL(it+1)^2);
            P31(:,idxSize+2) = Emax;
            % Growth and nutrient uptake
            if mutation(2) ~= 0
                % Flexible reference cell biomass
                % Growth
                growth1 = dt*b01.*limT.*limL;
                % Update internal nitrogen quota 
                P31(:,idxSize+1) = P31(:,idxSize+1) + rho - growth1;
                % Correct for excess uptake
                idx = find(P31(:,idxSize+1)>Qmax);
                rho(idx) = rho(idx) - (P31(idx,idxSize+1) - Qmax(idx));
                P31(idx,idxSize+1) = Qmax(idx);
                % Total nitrogen uptake
                muDt(3) = sum(rho);
            else
                % Constant reference cell biomass
                % Growth
                growth1 = dt*b01.*limN.*limT.*limL;   
                % Nutrient uptake
                muDt(3) = sum(growth1);
            end
            % Apply growth
            P31(:,1) = P31(:,1) + growth1;                 
            % Cell division
            [P31] = CellDivision(P31,b01,mutation,mutPb(3),sigma3,idxSize,b15_3,T);   
            % Grazing and mortality
            % Get internal nitrogen quota for mortality function
            if mutation(2) ~= 0
                Q = P31(:,idxSize+1);
            else
                Q = zeros(size(P31(:,1:2)));
            end
            % Total biomass P31
            C = sum(P31(:,1))*cpa3;
            % Grazing probability
            gPb31 = grazing(dt,pref3,muZ,Z(it),kP,C,type);
            % Calculate loss due to grazing and mortality
            [P31,~,mP31,mC31,gZ31] = mortality(P31,0,mPb31,0,gPb31,Q,it);
            % Transfer VEG to HET
            % Calculate transfer probability based on nutrient limitation
            if mutation(2) ~= 0                
                tPb312 = 0.33*tPb3*0.5*(1-tanh(2*pi*mean(limN)-pi));
            else
                tPb312 = 0.1*tPb3/mean(limN)^2;
            end
            % Call transfer function
            [P31,P32] = transfer(P31,P32,tPb312);
            % Transfer from VEG to RES when environmental conditions are unfavorable
            % Calculate mean growth rate for nitrogen saturation
            % Temperature limitation (Hense & Beckmann, 2006)
            limT = muMaxSat1.*(0.022+1./(0.25+exp(3./(T-T3) ...
                -0.5)+exp(-(500./(T-T3)-25))));
            omega_lc = 5.*limT;
            % Light limitation (Beckmann & Hense, 2004)
            limL = (alpha*IL(it+1))./sqrt(omega_lc.^2+alpha^2*IL(it+1)^2);
            % Mean relative growth rate for current time step
            mu12h_1(oldest31) = mean(dt*limT.*limL);    
            oldest31 = avIdx(oldest31,avTime3);
            if length(nonzeros(mu12h_1)) == avTime3 
                % Mean relative growth rate over 12 hours
                muMean2 = mean(mu12h_1);
                if (muMean2 < muCrit31) && ((ILTold - ILT) > epsilon)
                    % Calculate transfer probability
                    tPb313 = 7.5*tPb3*0.5*(1-tanh(2*pi*(muMean2/(muCrit31))-pi));
                    % Call transfer function
                    [P31,P33] = transfer(P31,P33,tPb313);
                end
            end
        end
        
        %% N2-fixation
        % Check if vegetative cells with heterocysts are present
        if isempty(P32)
            % Set mortality and grazing
            mP32 = 0;   % Mortality
            mC32 = 0;   % Carbon content of dead cells
            gZ32 = 0;   % Grazing loss
            % Set growth rate arry to zeros
            mu12h_2 = zeros(avTime3,1);
            % Set growth-related variables to nan
            if mutation(2) ~= 0
                muMaxSat32 = nan;
            end
            b02 = nan;
            growth2 = nan;
        else
            % Check for flexible traits
            % Optimum growth temperature
            if mutation(1) ~= 0
                % Flexible
                T3 = P32(:,2) - 16.43;
            else
                % Constant
                T3 = ones(size(P32(:,1)))*Topt3 - 16.43;
            end
            % Reference cell biomass
            if mutation(2) ~= 0
                % Flexible
                % Current cell biomass
                b = P32(:,1);
                % Reference cell biomass
                b02 = P32(:,idxSize);
                % Traits depending on reference cell biomass
                [~,Qmax] = CellQuota(b02);
                [muMaxSat32,~] = maxRates3(b02,Qmax,N(it));  
                muMaxSat32 = muMaxSat32/VegHet;
                % Traits depending on current cell biomass
                [Qmin,Qmax] = CellQuota(b);
                [muMaxSat2,~] = maxRates3(b,Qmax,N(it));
                muMaxSat2 = muMaxSat2/(3600);
            else
                % Constant
                b02 = b03*ones(size(P32(:,1)));
                muMax = omega0;
            end
            % Temperature limitation (Hense & Beckmann, 2006)
            limT = (1/VegHet)*muMaxSat2.*(0.022+1./(0.25+exp(3./(T-T3) ...
                -0.5)+exp(-(500./(T-T3)-25))));     
            omega_lc = 5.*muMaxSat2.*(0.022+1./(0.25+exp(3./(T-T3) ...
                -0.5)+exp(-(500./(T-T3)-25))));
            % light limitation (Beckmann & Hense, 2004)
            limL = (alpha*IL(it+1))./sqrt(omega_lc.^2+alpha^2*IL(it+1)^2);
            % Growth of individual cells
            sigmaE = 1 - (P32(:,idxSize+2)./Emax - 1).^n;   % Energy limitation
            growth2 = dt.*b02.*limT.*sigmaE;
            % Internal energy quota
            % Scale dimensionless energy quota with biomass
            E = P32(:,idxSize+2).*b02 + ...
                (omega_lc0 + Eperc.*(omega_lc-omega_lc0)).*dt.*b02.*limL.*(1-(P32(:,idxSize+2)./Emax).^n) - ...
                m*growth2 - growth2;
            % Correct excess energy quota
            idx = find(E>b02);
            E(idx) = b02(idx);
            % Correct excess energy usage
            idx = find(E<0);
            growth2(idx) = growth2(idx) - abs(E(idx)/(m+1));
            E(idx) = 0;
            % Convert energy quota back to dimensionless value
            P32(:,idxSize+2) = E./b02;
            % Current growth rate
            muP32 = mean(growth2./b02);
            % Apply growth
            P32(:,1) = P32(:,1) + growth2;             
            % Cell division
            [P32] = CellDivision(P32,b02,mutation,mutPb(3),sigma3,idxSize,b15_3,T);
            % Grazing and mortality
            % Get interanl nitrogen quota for mortality function
            if mutation(2) ~= 0
                Q = P32(:,idxSize+1);
            else
                Q = zeros(size(P32(:,1)));
            end
            % Total biomass of P32
            C = sum(P32(:,1))*cpa3;
            % Grazing probabiity
            gPb32 = grazing(dt,pref3,muZ,Z(it),kP,C,type);
            % Calculate loss due to grazing and mortality
            [P32,~,mP32,mC32,gZ32] = mortality(P32,0,mPb32,0,gPb32,Q,it);                   
            % Transfer to RES when environmental conditions are unfavorable
            % Growth rate for current time step
            if muP32 == 0
                mu12h_2(oldest32) = 1e-24;
            else
                mu12h_2(oldest32) = muP32;
            end
            oldest32 = avIdx(oldest32,avTime3);
            if length(nonzeros(mu12h_2)) == avTime3
                % Mean relative growth rate over 12 hours
                muMean = mean(mu12h_2);
                if (muMean < muCrit32) && ((ILTold - ILT) > epsilon)
                    % Call transfer function
                    [P32,P33] = transfer(P32,P33,0.67*tPb3);
                end
            end
        end
        
        %% Resting cells (akinetes)
        % Check if akinetes exist
        if isempty(P33)
            % Set mortality and grazing to zero
            mP33 = 0;   % Mortality
            mC33 = 0;   % Carbon content of dead cells
            gZ33 = 0;   % Grazing loss
            % Set growth rate array to zeros
            mu12h_3 = zeros(avTime3,1);
        else
            % Check for flexible traits
            % Optimum growth temperature
            if mutation(1) ~= 0
                % Flexible
                T3 = P33(:,2) - 16.43;
            else
                % Constant
                T3 = ones(size(P33(:,1)))*Topt3 - 16.43;
            end
            % Reference cell biomass
            if mutation(2) ~= 0
                % Flexible
                % Current cell biomass
                b = P33(:,1);
                % Reference cell biomass
                b0 = P33(:,idxSize);
                % Nutrient uptake for current cell biomass
                [muMax,rho,kN] = maxRates3(b,P33(:,idxSize+1),N(it));
                muMax = muMax/3600;
                rho = rho/VegRes;
                % Saturated growth rate for current cell biomass
                [~,Qmax] = CellQuota(b);
                [muMaxSat,~,~] = maxRates3(b,Qmax,N(it)); 
                muMaxSat = muMaxSat/3600;
            else
                % Constant
                b0 = b03*ones(size(P33(:,1)));
                muMax = omega0;
                muMaxSat = omega0;
            end  
            % Nutrient uptake during resting stage
            if mutation(2) ~= 0
                % Flexible reference cell biomass
                % Update internal nitrogen quota
                P33(:,idxSize+1) = P33(:,idxSize+1) + rho;
                % Correct excess quota
                idx = find(P33(:,idxSize+1)>Qmax);
                rho(idx) = rho(idx) - (P33(idx,idxSize+1) - Qmax(idx));
                P33(idx,idxSize+1) = Qmax(idx);
                % Calculate total uptake
                Nup = sum(rho);
            else
                % Constant reference cell biomass
                % Nutrient limitation (Michaelis-Mentes kinetics)
                limN = N(it)./(N(it)+kN3);
                % Temperature limitation (Hense & Beckmann, 2006)
                limT = muMax.*(0.022+1./(0.25+exp(3./(T-T3) ...
                -0.5)+exp(-(500./(T-T3)-25))));
                % Calculate total uptake
                Nup = sum(dt*b0.*limN.*limT)./VegRes;
            end
            % Calculate total cyanobacteria nitrogen uptake (P31 + P33)
            muDt(3) = muDt(3) + Nup;
            % Grazing, mortality, and burial
            % Get internal nitrogen quota for mortality function
            if mutation(2) ~= 0
                Q = P33(:,idxSize+1:idxSize+2);
            else
                Q = zeros(size(P33(:,1:2)));
            end
            % Total biomass of P33
            C = sum(P33(:,1))*cpa3;
            % Grazing probability
            gPb33 = grazing(dt,pref3,muZ,Z(it),kP,C,type);
            % Calculate loss due to grazing, mortality, and burial
            [P33,P33sed,mP33,mC33,gZ33] = mortality(P33,P33sed,mPb33,delta3,gPb33,Q,it);
            % Transfer to VEG when environmental conditions are favorable
            % Temperature limitation (Hense & Beckmann, 2006)
            limT = muMax.*(0.022+1./(0.25+exp(3./(T-T3) ...
                -0.5)+exp(-(500./(T-T3)-25))));
            omega_lc = 5.*muMaxSat.*(0.022+1./(0.25+exp(3./(T-T3) ...
                -0.5)+exp(-(500./(T-T3)-25))));
            % Light limitation (Beckmann & Hense, 2004)
            limL = (alpha*IL(it+1))./sqrt(omega_lc.^2+alpha^2*IL(it+1)^2);
            % Mean relative growth rate for current time step
            mu12h_3(oldest33) = mean(dt*limT.*limL);
            oldest33 = avIdx(oldest33,avTime3);
            if length(nonzeros(mu12h_3)) == avTime3
                % Mean relative growth rate over 12 hours
                muMean = mean(mu12h_3);     
                % Transfer from RES to VEG
                if (g3start+360*years(it) < days(it)) && (days(it) < g3end+360*years(it)) && (muMean >= muCrit3)
                    % Call transfer function
                    [P33,P31] = transfer(P33,P31,0.67*tPb3); 
                end
            end
        end
        % Resuspension
        if rsp == 1
            if (rspEnd+360*years(it) > days(it)) || (days(it) > rspStart+360*years(it))
                % Call resuspension function
                [P33,P33sed] = resuspension2(P33,P33sed,delta1*rspPerc,expProb,it,tScale);
            end
        end
        
        ILTold = ILT;
        
        %% Total cyanobacteria biomass
        P3sum(it+1,1) = sum(P31(:,1))*cpa3;         % Vegetative cells
        P3sum(it+1,2) = sum(P32(:,1))*cpa3;         % Vegetative cells with heterocysts
        P3sum(it+1,3) = sum(P33(:,1))*cpa3;         % Akinetes
        P(it+1,3) = P3sum(it+1,1)+P3sum(it+1,2)...  % Total cyanobacteria
        +P3sum(it+1,3);
    
        %% seasonal variation of biomass-related traits
        if (mutation(2) ~= 0)
            % P31
            if length(P31(:,1)) >= meanCrit
                seasonalTrait(it+1,3,1) = mean(P31(:,idxSize));    % Reference cell biomass [mmol N]
                seasonalTrait(it+1,3,2) = mean(kN31);              % Half saturation constant for nitrogen [mmol N m^-3]
                seasonalTrait(it+1,3,3) = mean(muMaxSat31)*24;     % Maximum saturated growth rate [d^-1]
                seasonalTrait(it+1,3,4) = mean(growth1./b01)*24;   % Actual growth rate [d^-1]
                seasonalTrait(it+1,3,5) = mean(P31(:,2));          % Optimum growth temperature [°C]
            end
            if length(P32(:,1)) >= meanCrit
                seasonalTrait(it+1,4,1) = mean(P32(:,idxSize));    % Reference cell biomass [mmol N]
                seasonalTrait(it+1,4,3) = mean(muMaxSat32)*24;     % Maximum (saturated) growth rate [d^-1]
                seasonalTrait(it+1,4,4) = mean(growth2./b02)*24;   % Actual growth rate [d^-1]
                seasonalTrait(it+1,4,5) = mean(P32(:,2));          % Optimum growth temperature [°C]
            end
        end
        % Save optimum temperature for grwoing and resting life cycle stages
        if (length(P31(:,1)) + length(P32(:,1))) >= meanCrit
            mTopt_lc(it,5) = mean([P31(:,2);P32(:,2)]);
        end
        if length(P33(:,1)) >= meanCrit
            mTopt_lc(it,6) = mean(P33(:,2));
        end
        
        %% Mean trait values (P31, P32, P33)
        % Optimum temperature and reference cell biomass
        count = 1;
        for iTrait = 1:numTraits
            if mutation(iTrait) ~= 0
                meanTrait(it+1,3,count) = (sum(P31(:,count+1))+...
                    sum(P32(:,count+1)) + sum(P33(:,count+1)))/ ...
                    (length(P31(:,1))+length(P32(:,1))+length(P33(:,1)));
                count = count + 1;
            end
        end
        % Cell size-related traits
        if mutation(2) ~= 0
            meanTrait(it+1,3,count) = mean(kN31);               % Half saturation constant for nitrogen P31 [mmol N m^-3]
            meanTrait(it+1,3,count+1) = mean(muMaxSat31)*24;    % Maximum saturated growth rate P31 [d^-1]
            meanTrait(it+1,3,count+2) = mean(growth1./b01)*24;  % Actual growth rate P31 [d^-1]
            meanTrait(it+1,4,count+1) = mean(muMaxSat32)*24;    % Maximum (saturated) growth rate P32 [d^-1]
            meanTrait(it+1,4,count+2) = mean(growth2./b02)*24;  % Actual growth rate P32 [d^-1]
        end

        if (mutCya == 0) && (mutTmp == 1)
            mutation(1) = 1;
        end

    else
        % If no cyanobacteria are simulated, set the corresponding parameters to zero
        cpa3 = 0;
        muDt(3) = 0;
        mP31 = 0;
        mP32 = 0;
        mP33 = 0;
        mC31 = 0;
        mC32 = 0;
        mC33 = 0;
        gZ31 = 0;
        gZ32 = 0;
        gZ33 = 0;
    end
    
    %% Total phytoplankton biomass  
    P(it+1,4) = sum(P(it+1,1:3));
    
    %% Nitrogen
    N(it+1) = N(it) - (muDt(1)*cpa1+muDt(2)*cpa2+muDt(3)*cpa3) + dt*metZ*Z(it)...
        + dt*rD*D(it);
    
    %% Detritus
    D(it+1) = D(it) + (mP11+mP12)*cpa1+(mP21+mP22)*cpa2+(mP31+mP32+mP33)*cpa3...
        + (1-beta)*((gZ11+gZ12)*cpa1+(gZ21+gZ22)*cpa2+(gZ31+gZ32+gZ33)*cpa3)...
        + dt*mZ*Z(it)^2 - dt*rD*D(it) - dt*sD*D(it)^2;
    
    %% Zooplankton
    if species(4) == 1
        Z(it+1) = Z(it) + beta*((gZ11+gZ12)*cpa1+(gZ21+gZ22)*cpa2+(gZ31+gZ32+gZ33)*cpa3)...
            - dt*metZ*Z(it) - dt*mZ*Z(it)^2;
    end

    %% Save Topt distribution for each month
    if it/(24 *30) - floor(it/(24*30)) == 0.5
        Topt_total{ceil(it/(24*30))-(years(it)*12),1,years(it)+1} = [P11(:,2);P12(:,2)];
        Topt_total{ceil(it/(24*30))-(years(it)*12),2,years(it)+1} = [P21(:,2);P22(:,2)];
        Topt_total{ceil(it/(24*30))-(years(it)*12),3,years(it)+1} = [P31(:,2);P32(:,2);P33(:,2)];
    end
        
    %% Print finished month to screen
    if it/(24*30) == months(1 + mCounter)
        fprintf('month %d, din: %4.3f, dia: %4.3f, cya: %4.3f, zoo: %4.3f\n',...
            months(1 + mCounter),P(it+1,1),P(it+1,2),P(it+1,3),Z(it));
        mCounter = mCounter + 1;
    end

    %% Save output every 10 years
    if fileSave == 1
        savePoints = saveStart:saveStep:saveEnd;
        if it/(24*30) == savePoints(iSave)
            if iSave > 1
                fname = sprintf(filename_save,filenumber,savePoints(iSave-1));
                delete(fname)
            end
            fname = sprintf(filename_save,filenumber,savePoints(iSave));
            save(fname)
            iSave = iSave + 1;
        end
    end
    
end

%% VISUAL CONTROL
green1 = [0 0.7 0.2];
grey1 = [0.3 0.3 0.3];
orange1 = [255/256 165/256 0];
yellow2 = [1 0.6 0];
tDays = time/24;
tYears = tDays/(30*12);

%% SEASONALITY
%% NPZD ecosystem components
str = [];

figure(1)

plot(tDays,P(:,4),'color',green1,'LineWidth',1.5)
str = [str "Phytoplankton"];
hold on
if species(4) == 1
    plot(tDays,Z,'color',orange1,'LineWidth',1.5)
    str = [str "Zooplankton"];
end
plot(tDays,N,'k','LineWidth',1.5)
plot(tDays,D,'k--','LineWidth',1.5)
str = [str "Nitrogen" "Detritus"];
legend(str')

ylabel('Biomass [mmol N m^{-3}]','FontSize',12)
xlim([dayPlot dayPlot+360])
xticks([dayPlot+15 dayPlot+45 dayPlot+75 dayPlot+105 dayPlot+135 ...
    dayPlot+165 dayPlot+195 dayPlot+225 dayPlot+255 dayPlot+285 dayPlot+315 dayPlot+345])
xticklabels({'J','F','M','A','M','J','J','A','S','O','N','D'})

%% Phytoplankton groups resolved
figure(2)
str = [];

plot(tDays,N,'k','LineWidth',1.5)
hold on
plot(tDays,D,'k--','LineWidth',1.5)
str = [str "Nitrogen" "Detritus"];

if species(1) == 1
    str = [str "Dinoflagellates"];
    plot(tDays,P(:,1),'color',green1,'LineWidth',1.5)
    hold on
end
if species(2) == 1
    str = [str "Diatoms"];
    plot(tDays,P(:,2),'--','color',green1,'LineWidth',1.5)
    hold on
end
if species(3) == 1
    str = [str "Cyanobacteria"];
    plot(tDays,P(:,3),'-.','color',green1,'LineWidth',1.5)
    hold on
end
if species(4) == 1
    str = [str "Zooplankton"];
    plot(tDays,Z,'color',orange1,'LineWidth',1.5)
    hold on
end

l = legend(str,'Location','northeast');
l.FontSize = 10;
ylabel('Biomass [mmol N m^{-3}]','FontSize',12)
xlim([dayPlot dayPlot+360])
xticks([dayPlot+15 dayPlot+45 dayPlot+75 dayPlot+105 dayPlot+135 ...
    dayPlot+165 dayPlot+195 dayPlot+225 dayPlot+255 dayPlot+285 dayPlot+315 dayPlot+345])
xticklabels({'J','F','M','A','M','J','J','A','S','O','N','D'})
 
%% Phytoplankton life cycle stages
str = [];

figure(3)

if species(1) == 1
    str = [str "Din_{veg}" "Din_{res}"];
    plot(tDays,P1sum(:,1),'Color',yellow2,'LineWidth',1.5)
    hold on
    plot(tDays,P1sum(:,2),'--','Color',yellow2,'LineWidth',1.5)
end
if species (2) == 1
    str = [str "Dia_{veg}" "Dia_{res}"];
    plot(tDays,P2sum(:,1),'r','LineWidth',1.5)
    hold on
    plot(tDays,P2sum(:,2),'r--','LineWidth',1.5)
end
if species (3) == 1
    str = [str "Cya_{veg}" "Cya_{het}" "Cya_{res}"];
    plot(tDays,P3sum(:,1),'b','LineWidth',1.5)
    hold on
    plot(tDays,P3sum(:,2),'b--','LineWidth',1.5)
    plot(tDays,P3sum(:,3),'b-.','LineWidth',1.5)
end

l = legend(str,'Location','northeast');
l.FontSize = 10;
ylabel('Biomass [mmol N m^{-3}]','FontSize',12)
xlim([dayPlot dayPlot+360])
xticks([dayPlot+15 dayPlot+45 dayPlot+75 dayPlot+105 dayPlot+135 ...
    dayPlot+165 dayPlot+195 dayPlot+225 dayPlot+255 dayPlot+285 dayPlot+315 dayPlot+345])
xticklabels({'J','F','M','A','M','J','J','A','S','O','N','D'})

%% Cell size and related traits
CellSizePlot3(4,tDays,dayPlot,temp,seasonalTrait(:,1,1),seasonalTrait(:,2,1),seasonalTrait(:,3:4,1));
  
%% LONG-TERM VARIABILITY
%% Annual mean biomasses
meanYears = linspace(1,Nyears,Nyears);
Pmean = zeros(Nyears,4);
spy = 24*360-2;

for iSpecies = 1:4
    count = 2;
    for iYear = 1:Nyears
        Pmean(iYear,iSpecies) = mean(P(count:count+spy,iSpecies));
        count = count + spy + 1;
    end
end

figure(5)
plot(meanYears,Pmean(:,1),'color',yellow2,'LineWidth',1.5)
hold on
plot(meanYears,Pmean(:,2),'r','LineWidth',1.5)
plot(meanYears,Pmean(:,3),'b','LineWidth',1.5)
l = legend('Dinoflagellates','Diatoms','Cyanobacteria','Location','southeast');
l.FontSize = 10;
xlabel('Year','FontSize',12)
ylabel('Annual mean biomass [mmol N m^{-3}]','FontSize',12)  

%% Evolution of Topt
 if mutation(1) ~= 0
    figure(6)
    plot(tYears,temp,'k','LineWidth',1.5)
    hold on
    plot(tYears,meanTrait(:,1,1),'color',green1,'LineWidth',1.5)
    plot(tYears,meanTrait(:,2,1),'--','color',green1,'LineWidth',1.5)
    plot(tYears,meanTrait(:,3,1),'-.','color',green1,'LineWidth',1.5)
    l = legend('T_{env}','Dinoflagellates','Diatoms','Cyanobacteria','Location','southwest');
    l.FontSize = 10;
    xlabel('Year','FontSize',12)
    ylabel('Temperature [°C]','FontSize',12)
 end
 
%% Topt histograms
%% Dinoflagellates
figure(7)
yyaxis left
ax = gca;
h1 = histogram([P11(:,2);P12(:,2)],'BinWidth',0.15,'FaceAlpha',0.75,'FaceColor','red','LineWidth',1.0,'Normalization','probability');
ax.YColor = 'r';
xlabel('T_{opt} [°C]','FontSize',12)
ylabel('Relative biomass','FontSize',12)
hold on
yyaxis right
ax = gca;
if ref == 1
    h2 = histogram(Topt1,'FaceColor',grey1,'FaceAlpha',0.5,'LineWidth',1.0,'Normalization','probability');
else
    h2 = histogram([s.P11(:,2);s.P12(:,2)],'FaceColor',grey1,'FaceAlpha',0.5,'LineWidth',1.0,'Normalization','probability');
end
ax.YColor = grey1;
h2.BinWidth = h1.BinWidth;
ylabel('Relative biomass','FontSize',12)

%% Diatoms
figure(8)
yyaxis left
ax = gca;
h1 = histogram([P21(:,2);P22(:,2)],'BinWidth',0.15,'FaceAlpha',0.75,'FaceColor','red','LineWidth',1.0,'Normalization','probability');
ax.YColor = 'r';
xlabel('T_{opt} [°C]','FontSize',12)
ylabel('Relative biomass','FontSize',12)
hold on
yyaxis right
ax = gca;
if ref == 1
    h2 = histogram(Topt2,'FaceColor',grey1,'FaceAlpha',0.5,'LineWidth',1.0,'Normalization','probability');
else
    h2 = histogram([s.P21(:,2);s.P22(:,2)],'FaceColor',grey1,'FaceAlpha',0.5,'LineWidth',1.0,'Normalization','probability');
end
ax.YColor = grey1;
h2.BinWidth = h1.BinWidth;
ylabel('Relative biomass','FontSize',12)

%% Cyanobacteria
figure(9)
yyaxis left
ax = gca;
h1 = histogram([P31(:,2);P32(:,2);P33(:,2)],'BinWidth',0.15,'FaceAlpha',0.75,'FaceColor','red','LineWidth',1.0,'Normalization','probability');
ax.YColor = 'r';
xlabel('T_{opt} [°C]','FontSize',12)
ylabel('Relative biomass','FontSize',12)
hold on
yyaxis right
ax = gca;
if ref == 1
    h2 = histogram(Topt3,'FaceColor',grey1,'FaceAlpha',0.5,'LineWidth',1.0,'Normalization','probability');
else
    h2 = histogram([s.P31(:,2);s.P32(:,2);s.P33(:,2)],'FaceColor',grey1,'FaceAlpha',0.5,'LineWidth',1.0,'Normalization','probability');
end
h2.BinWidth = h1.BinWidth;
ax.YColor = grey1;
ylabel('Relative biomass','FontSize',12)
