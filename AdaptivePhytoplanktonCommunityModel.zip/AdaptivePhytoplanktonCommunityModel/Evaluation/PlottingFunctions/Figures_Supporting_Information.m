%% Figures_Supporting_Information.m
% Script to create Figs. S1-S12 from the Supporting Information

close all
clearvars

n = 2;       % Time to pause execution before saving figures [s]

%% load files
C = load('../Output_Files/C_vars.mat');
CA = load('../Output_Files/CA_vars.mat');
CAR = load('../Output_Files/CAR_vars.mat');
W = load('../Output_Files/W_vars.mat');
WA = load('../Output_Files/WA_vars.mat');
WAR = load('../Output_Files/WAR_vars.mat');

%% Fig. S1: time scale of ecological changes
yellow2 = [1 0.6 0];
P = CA.Pmean;
idx = CA.idx;
time = 1:100;

figure(1)
% Phytoplankton annual biomass
subplot(2,1,1)
plot(time,P(:,1),'Color',yellow2,'LineWidth',1.1)
hold on
plot(time,P(:,2),'r','LineWidth',1.1)
plot(time,P(:,3),'b','LineWidth',1.1)
set(gca,'XTickLabels',[],'FontSize',9,'Position',[0.1 0.55 0.82 0.405])
ylabel('Biomass [mmol N m^{-3}]','FontSize',9)
xlim([1 100])
l = legend('Dinoflagellates','Diatoms','Cyanobacteria','Location','northwest');
l.FontSize = 8;
l.Position(1) = l.Position(1) - 0.0225;
l.Position(2) = l.Position(2) + 0.021;

% Phytoplankton bloom timing
subplot(2,1,2)
plot(time,idx(:,1)-idx(1,1),'Color',yellow2,'LineWidth',1.1)
hold on
plot(time,idx(:,2)-idx(1,2),'r','LineWidth',1.1)
plot(time,idx(:,3)-idx(1,3),'b','LineWidth',1.1)
plot(time,idx(:,4)-idx(1,4),'r-.','LineWidth',1.1)
ylabel('Shift in bloom timing [d]','FontSize',9)
xlabel('Time [yr]','FontSize',9)
set(gca,'Position',[0.1 0.09 0.82 0.405],'FontSize',9)
xlim([1 100])

l = legend('Dinoflagellates','Diatoms spring','Cyanobacteria','Diatoms autumn','Location','southwest');
l.AutoUpdate = 'off';
l.PlotChildren = l.PlotChildren([1,2,4,3]);
l.FontSize = 8;
l.Position(1) = l.Position(1) - 0.0222;
l.Position(2) = l.Position(2) - 0.0228;

%% save figure
pause(n)
fig = figure(1);
fig.Units = 'centimeters';
fig.Position = [0 0 12.7 10.5];
figureName = '../Output_Plots/FigS1.png';
exportgraphics(fig,figureName,'Resolution',1200)

%% Fig. S2: Topt evolution over 100 years
gray2 = [0.5 0.5 0.5];
yellow2 = [1 0.6 0];
mTopt = CA.mTopt;
Topt_annual_CA = CA.Topt_annual;
time = linspace(0,100,864000);

figure(2)
% Temporal evolution
subplot(4,3,[1 3])
yyaxis right
plot(time,CA.temp(1:end-1),'Color',gray2)
hold on
set(gca,'YColor',gray2,'FontSize',8)
ylabel('{\it T}_{env} [°C]','FontSize',8)
xlabel('Time [yr]','FontSize',8)
xlim([0 100])

yyaxis left
plot(time,mTopt(:,1)-mTopt(1,1),'Color',yellow2,'LineWidth',1.15)
hold on
plot(time,mTopt(:,2)-mTopt(1,2),'-r','LineWidth',1.15)
plot(time,mTopt(:,3)-mTopt(1,3),'-b','LineWidth',1.15)
set(gca,'Position',[0.09 0.77 0.835 0.21],'YColor','k')
yl = ylabel('Change in {\it T}_{opt} [°C]','FontSize',8);
yl.Position(1) = yl.Position(1) - 0.5;
yl.Position(2) = yl.Position(2) + 0.3;
xlim([0 100])

l = legend('Dinoflagellates','Diatoms','Cyanobacteria','Location','east');
l.FontSize = 7;

% Topt histogram after 10 years
% Dinoflagellates
subplot(4,3,4)
bw = 0.2;
lw = 0.25;
yyaxis right
histogram(10.8,'FaceColor',gray2,'BinWidth',bw,'LineWidth',lw,'Normalization','probability')
hold on
set(gca,'Position',[0.09 0.525 0.225 0.16],'YColor',gray2)

yyaxis left
histogram(Topt_annual_CA{10,1},'FaceColor',yellow2,'BinWidth',bw,'LineWidth',lw,'Normalization','probability')
set(gca,'YColor',yellow2,'FontSize',8)
ylim([0 0.15])
xlim([2 12])

annotation('textbox',[0.085 0.54 0.15 0.15],'String','10 years','EdgeColor',...
    'none','FontWeight','normal','FontSize',8)

% Diatoms
subplot(4,3,5)
bw = 0.14;
lw = 0.25;
yyaxis right
histogram(12.0,'FaceColor',gray2,'BinWidth',bw,'LineWidth',lw,'Normalization','probability')
set(gca,'Position',[0.395 0.525 0.225 0.16],'YColor',gray2)

yyaxis left
histogram(Topt_annual_CA{10,2},'FaceColor','r','BinWidth',bw,'LineWidth',lw,'Normalization','probability')
set(gca,'YColor','r','FontSize',8)
yticks([0 0.03 0.06 0.09])
yticklabels({'0','0.03','0.06','0.09'})
xticks([8 11.5 15])
xticklabels({'8','11.5','15'})
ylim([0 0.09])
xlim([8 15])

% Cyanobacteria
subplot(4,3,6)
bw = 0.2;
lw = 0.25;
yyaxis right
histogram(28.5,'FaceColor',gray2,'BinWidth',bw,'LineWidth',lw,'Normalization','probability')
set(gca,'YColor',gray2)

yyaxis left
histogram(Topt_annual_CA{10,3},'FaceColor','b','BinWidth',bw,'LineWidth',lw,'Normalization','probability')
set(gca,'Position',[0.7 0.525 0.225 0.16],'YColor','b','FontSize',8)
yticks([0 0.04 0.08 0.12])
yticklabels({'0','0.04','0.08','0.12'})
ylim([0 0.12])
xlim([22 32])

% Topt histogram after 50 years
% Dinoflagellates
subplot(4,3,7)
bw = 0.2;
lw = 0.25;
yyaxis right
histogram(10.8,'FaceColor',gray2,'BinWidth',bw,'LineWidth',lw,'Normalization','probability')
hold on
set(gca,'YColor',gray2)

yyaxis left
histogram(Topt_annual_CA{50,1},'FaceColor',yellow2,'BinWidth',bw,'LineWidth',lw,'Normalization','probability')
set(gca,'Position',[0.09 0.3125 0.225 0.16],'YColor',yellow2,'FontSize',8)
yl = ylabel('Relative abundance','FontSize',8);
yl.Color = 'k';
yl.Position(1) = yl.Position(1) - 1.25;
yl.Position(2) = yl.Position(2) + 0.0225;
ylim([0 0.15])
xlim([2 12])

annotation('textbox',[0.085 0.3275 0.15 0.15],'String','50 years','EdgeColor',...
    'none','FontWeight','normal','FontSize',8)

% Diatoms
subplot(4,3,8)
bw = 0.14;
lw = 0.25;
yyaxis right
histogram(12.0,'FaceColor',gray2,'BinWidth',bw,'LineWidth',lw,'Normalization','probability')
set(gca,'YColor',gray2)

yyaxis left
histogram(Topt_annual_CA{50,2},'FaceColor','r','BinWidth',bw,'LineWidth',lw,'Normalization','probability')
set(gca,'Position',[0.395 0.3125 0.225 0.16],'YColor','r','FontSize',8)
yticks([0 0.03 0.06 0.09])
yticklabels({'0','0.03','0.06','0.09'})
xticks([8 11.5 15])
xticklabels({'8','11.5','15'})
ylim([0 0.09])
xlim([8 15])

% Cyanobacteria
subplot(4,3,9)
bw = 0.2;
lw = 0.25;
yyaxis right
histogram(28.5,'FaceColor',gray2,'BinWidth',bw,'LineWidth',lw,'Normalization','probability')
set(gca,'YColor',gray2)

yyaxis left
histogram(Topt_annual_CA{50,3},'FaceColor','b','BinWidth',bw,'LineWidth',lw,'Normalization','probability')
set(gca,'Position',[0.7 0.3125 0.225 0.16],'YColor','b','FontSize',8)
yticks([0 0.04 0.08 0.12])
yticklabels({'0','0.04','0.08','0.12'})
ylim([0 0.12])
xlim([22 32])

% Topt histogram after 100 years
% Dinoflagellates
subplot(4,3,10)
bw = 0.2;
lw = 0.25;
yyaxis right
histogram(10.8,'FaceColor',gray2,'BinWidth',bw,'LineWidth',lw,'Normalization','probability')
hold on
set(gca,'Position',[0.09 0.1 0.225 0.16],'YColor',gray2)

yyaxis left
histogram(Topt_annual_CA{100,1},'FaceColor',yellow2,'BinWidth',bw,'LineWidth',lw,'Normalization','probability')
set(gca,'YColor',yellow2,'FontSize',8)
ylabel('','FontSize',10)
xlabel('{\it T}_{opt} [°C]','FontSize',8)
ylim([0 0.15])
xlim([2 12])

annotation('textbox',[0.085 0.115 0.15 0.15],'String','100 years','EdgeColor',...
    'none','FontWeight','normal','FontSize',8)

% Diatoms
subplot(4,3,11)
bw = 0.14;
lw = 0.25;
yyaxis right
histogram(12.0,'FaceColor',gray2,'BinWidth',bw,'LineWidth',lw,'Normalization','probability')
set(gca,'YColor',gray2)

yyaxis left
histogram(Topt_annual_CA{100,2},'FaceColor','r','BinWidth',bw,'LineWidth',lw,'Normalization','probability')
set(gca,'Position',[0.395 0.1 0.225 0.16],'YColor','r','FontSize',8)
xlabel('{\it T}_{opt} [°C]','FontSize',8)
yticks([0 0.03 0.06 0.09])
yticklabels({'0','0.03','0.06','0.09'})
xticks([8 11.5 15])
xticklabels({'8','11.5','15'})
ylim([0 0.09])
xlim([8 15])

% Cyanobacteria
subplot(4,3,12)
bw = 0.2;
lw = 0.25;
yyaxis right
histogram(28.5,'FaceColor',gray2,'BinWidth',bw,'LineWidth',lw,'Normalization','probability')
set(gca,'Position',[0.7 0.1 0.225 0.16],'YColor',gray2)

yyaxis left
histogram(Topt_annual_CA{100,3},'FaceColor','b','BinWidth',bw,'LineWidth',lw,'FaceAlpha',0.5,'Normalization','probability')
set(gca,'YColor','b','FontSize',8)
yticks([0 0.04 0.08 0.12])
yticklabels({'0','0.04','0.08','0.12'})
ylim([0 0.12])
xlim([22 32])
xlabel('{\it T}_{opt} [°C]','FontSize',8)

%% save figure
pause(n)
fig = figure(2);
fig.Units = 'centimeters';
fig.Position = [0 0 12.7 12.7];
figureName = '../Output_Plots/FigS2.png';
exportgraphics(fig,figureName,'Resolution',1200)

%% Fig. S3: environmental forcing
% Temperature forcing
% Constant seasonal cycle
T_season = CA.temp(end-360*24+1:end);
% Warming scenario
T_increase = WA.temp(1:end-1);
% Irradiance
irradiance = CA.IL(end-360*24+1:end);

% Visualization
time = linspace(0,100,864000);
year = 1:8640;

blue2 = [0.3 0.4 0.65];
orange2 = [0.9490 0.6940 0.1250];

figure(3)
% Control
subplot(2,1,1)
set(gca,'Position',[0.085 0.575 0.8 0.415],'FontSize',9)
yyaxis right
plot(year,irradiance,'Color',orange2,'LineWidth',1.25)
hold on
ylabel('Irradiance [w m^{-2}]','FontSize',9)
set(gca,'YColor',orange2)

yyaxis left
plot(year,T_season,'Color',blue2,'LineWidth',1.25)
set(gca,'YColor',blue2)
ylabel('Temperature [°C]','FontSize',9)

xlim([0 24*360])
xticks([15*24 45*24 75*24 105*24 135*24 165*24 195*24 225*24 255*24 285*24 315*24 345*24])
xticklabels({'J','F','M','A','M','J','J','A','S','O','N','D'})
xtickangle(0)

% Warming
ax = subplot(2,1,2);
plot(time,T_increase,'Color',blue2)

set(gca,'Position',[0.085 0.09 0.8 0.415],'FontSize',9)

ylabel('Temperature [°C]','FontSize',9)
ax.YColor = blue2;
xlabel('Time [yr]','FontSize',9)
xlim([0 100])
ylim([0 25])

%% save figure
pause(n)
fig = figure(3);
fig.Units = 'centimeters';
fig.Position = [0 0 12.7 10.16];
figureName = '../Output_Plots/FigS3.png';
exportgraphics(fig,figureName,'Resolution',1200)

%% Fig. S4: thermal reaction norms
% Mean optimum temperatures
% Dinoflagellates
Topt(1,1) = mean(CA.Topt{1});         % CA
Topt(1,2) = mean(WA.Topt{1});         % WA
Topt(1,3) = mean(CAR.Topt{1});        % CAR
Topt(1,4) = mean(WAR.Topt{1});        % WAR
% Diatoms
Topt(2,1) = mean(CA.Topt{2});         % CA
Topt(2,2) = mean(WA.Topt{2});         % WA
Topt(2,3) = mean(CAR.Topt{2});        % CAR
Topt(2,4) = mean(WAR.Topt{2});        % WAR
% Cyanobacteria
Topt(3,1) = mean(CA.Topt{3});         % CA
Topt(3,2) = mean(WA.Topt{3});         % WA
Topt(3,3) = mean(CAR.Topt{3});        % CAR
Topt(3,4) = mean(WAR.Topt{3});        % WAR

% Temperature responses
T = -30:0.001:40;
% Dinoflagellates
limT1 = zeros(length(T),5);
limT1(:,1) = exp(-(T-CA.Topt1).^2./(CA.Tl1-CA.Tl2*sign(T-CA.Topt1)).^2);
limT1(:,2) = exp(-(T-Topt(1,1)).^2./(CA.Tl1-CA.Tl2*sign(T-Topt(1,1))).^2);
limT1(:,3) = exp(-(T-Topt(1,2)).^2./(CA.Tl1-CA.Tl2*sign(T-Topt(1,2))).^2);
limT1(:,4) = exp(-(T-Topt(1,3)).^2./(CA.Tl1-CA.Tl2*sign(T-Topt(1,3))).^2);
limT1(:,5) = exp(-(T-Topt(1,4)).^2./(CA.Tl1-CA.Tl2*sign(T-Topt(1,4))).^2);
% Diatoms
Topt2 = [CA.Topt2;Topt(2,:)'];
limT2 = zeros(length(T),5);
for iTopt = 1:length(Topt2)
    for iT = 1:length(T)
        if T(iT) <= Topt2(iTopt)
            limT2(iT,iTopt) = exp(-(abs(T(iT)-Topt2(iTopt))/CA.theta1)^2);
        else
            limT2(iT,iTopt) = exp(-(abs(T(iT)-Topt2(iTopt))/CA.theta2)^3);
        end
    end
end
% Cyanobacteria
T3 = [CA.Topt3;Topt(3,:)'] - 16.43;
limT3 = 0.022+1./(0.25+exp(3./(T-T3)-0.5)+exp(-(500./(T-T3)-25)));
limT3 = limT3';

% Visualization
% Define colors
red2 = [235/255 94/255 40/255];
blue2 = [137/255 131/255 120/255];

figure(4)
% Dinoflagellates
subplot(3,1,1)
plot(T,limT1(:,1),'k','LineWidth',0.75)
hold on
plot(T,limT1(:,2),'Color',blue2,'LineWidth',0.75)
plot(T,limT1(:,3),'Color',red2,'LineWidth',0.75)
plot(T,limT1(:,4),'--','Color',blue2,'LineWidth',0.75)
plot(T,limT1(:,5),'--','Color',red2,'LineWidth',0.75)

set(gca,'Position',[0.085 0.725 0.8 0.26])
xlim([-25 15])
ylabel('lim_{{\it T}1} [-]','FontSize',9)

annotation('textbox',[0.085 0.685 0.3 0.3],'String','Dinoflagellates','EdgeColor',...
    'none','FontWeight','normal','FontSize',9)

% Diatoms
subplot(3,1,2)
plot(T,limT2(:,1),'k','LineWidth',0.75)
hold on
plot(T,limT2(:,2),'Color',blue2,'LineWidth',0.75)
plot(T,limT2(:,3),'Color',red2,'LineWidth',0.75)
plot(T,limT2(:,4),'--','Color',blue2,'LineWidth',0.75)
plot(T,limT2(:,5),'--','Color',red2,'LineWidth',0.75)
set(gca,'Position',[0.085 0.4 0.8 0.26])
xlim([-5 20])
ylabel('lim_{{\it T}2} [-]','FontSize',9)

annotation('textbox',[0.085 0.36 0.3 0.3],'String','Diatoms','EdgeColor',...
    'none','FontWeight','normal','FontSize',9)

% Cyanobacteria
subplot(3,1,3)
plot(T,limT3(:,1),'k','LineWidth',0.75)
hold on
plot(T,limT3(:,2),'Color',blue2,'LineWidth',0.75)
plot(T,limT3(:,3),'Color',red2,'LineWidth',0.75)
plot(T,limT3(:,4),'--','Color',blue2,'LineWidth',0.75)
plot(T,limT3(:,5),'--','Color',red2,'LineWidth',0.75)

set(gca,'Position',[0.085 0.075 0.8 0.26])
xl = xlabel('Temperature [°C]','FontSize',9);
xl.Position(1) = xl.Position(1) + 20;
xl.Position(2) = xl.Position(2) + 0.05;
xlim([10 40])
ylabel('lim_{{\it T}3} [-]','FontSize',9)

annotation('textbox',[0.085 0.035 0.3 0.3],'String','Cyanobacteria','EdgeColor',...
    'none','FontWeight','normal','FontSize',9)

l = legend('Initial','CA','WA','CAR','WAR','Location','northeast');
l.AutoUpdate = 'off';
l.PlotChildren = l.PlotChildren([1,2,4,3,5]);
l.Position(1) = l.Position(1) + 0.0222;
l.Position(2) = l.Position(2) + 0.0147;
l.FontSize = 7.5;

%% save figure
pause(n)
fig = figure(4);
fig.Units = 'centimeters';
fig.Position = [0 0 12.7 10.16];
figureName = '../Output_Plots/FigS4.png';
exportgraphics(fig,figureName,'Resolution',1200)

%% Fig. S5: nutrient and light limitation
addpath(genpath('Functions'))
N = 0:0.01:7.0;                % Nitrogen [mmol N m^-3]
I = 0:0.01:350;                % Irradiance [W m^-2]

% Half saturation constants (15°C)
kN(1) = 0.17*CA.V15_1.^0.27;
kN(2) = 0.17*CA.V15_2.^0.27;
kN(3) = 0.17*CA.V15_3.^0.27;
% Nitrogen limitation (15°C)
limN = zeros(length(N),3);
limN(:,1) = N./(kN(1)+N);
limN(:,2) = N./(kN(2)+N);
limN(:,3) = N./(kN(3)+N);

% Light limitation (15°C)
% Dinoflagellates
limL = zeros(length(I),3);
[~,Qmax] = CellQuota(CA.b15_1);
[muMax,~,~] = maxRates3(CA.b15_1,Qmax,1);
limL(:,1) = 1 - exp((-CA.i3.*I)./muMax);
% Diatoms
[~,Qmax] = CellQuota(CA.b15_2);
[muMax,~,~] = maxRates3(CA.b15_2,Qmax,1);
limL(:,2) = 1 - exp((-CA.alpha2.*I)./muMax);
% Cyanobacteria
T = 15;
T3 = CA.Topt3 - 16.43;
[~,Qmax] = CellQuota(CA.b15_3);
[muMax,~,~] = maxRates3(CA.b15_3,Qmax,1);
omega_lc = 5.*muMax./3600*(0.022+1./(0.25+exp(3./(T-T3) ...
    -0.5)+exp(-(500./(T-T3)-25))));
limL(:,3) = (CA.alpha.*I)./sqrt(omega_lc.^2+CA.alpha^2.*I.^2);

% visualization
yellow2 = [1 0.6 0];

figure(5)
% Nitrogen limitation
subplot(2,1,1)
plot(N,limN(:,1),'Color',yellow2,'LineWidth',1)
hold on
plot(N,limN(:,2),'r','LineWidth',1)
plot(N,limN(:,3),'b','LineWidth',1)

set(gca,'Position',[0.085 0.58 0.8 0.37])

xl = xlabel('Nitrogen concentration [mmol N m^{-3}]','FontSize',9);
xl.Position(2) = xl.Position(2) + 0.03;
ylabel('Nitrogen limitation [-]','FontSize',9)

l = legend('Dinoflagellates','Diatoms','Cyanobacteria','Location','southeast');
l.FontSize = 8;

% Light limitation
subplot(2,1,2)
plot(I,limL(:,1),'Color',yellow2,'LineWidth',1)
hold on
plot(I,limL(:,2),'r','LineWidth',1)
plot(I,limL(:,3),'b','LineWidth',1)

set(gca,'Position',[0.085 0.1 0.8 0.37])

xl = xlabel('Irradiance [W m^{-2}]','FontSize',9);
xl.Position(2) = xl.Position(2) + 0.03;
ylabel('Light limitation [-]','FontSize',9)

%% save figure
pause(n)
fig = figure(5);
fig.Units = 'centimeters';
fig.Position = [0 0 12.7 10.16];
figureName = '../Output_Plots/FigS5.png';
exportgraphics(fig,figureName,'Resolution',1200)

%% Fig. S6: limiting factors throughout the seasonal cycle
N = CA.N(end-360*24+1:end);               % Nitrogen [mmol N m^-3]
T = CA.temp(1:360*24);                    % Temperature [°C]
I = CA.IL(1:360*24);                      % Irradiance [W m^-2]
CS = CA.meanTrait(end-360*24+1:end,1:3);  % Cell size [mu m^3]
mT = CA.mTopt(end-360*24+1:end,:);        % Mean Topt [°C]

% Preallocation
limN = zeros(length(N),3);
limT = zeros(length(T),3);
limL = zeros(length(I),3);

for it = 1:360*24
    % Dinoflagellates
    [~,Qmax] = CellQuota(CS(it,1));
    [muMax,~,kN] = maxRates3(CS(it,1),Qmax,N(it));
    limN(it,1) = N(it)/(kN + N(it));
    limT(it,1) = exp(-(T(it)-mT(it,1)).^2./(CA.Tl1-CA.Tl2*sign(T(it)- mT(it,1))).^2);
    limL(it,1) = 1 - exp((-CA.i3.*I(it))./muMax);
    % Diatoms
    [~,Qmax] = CellQuota(CS(it,2));
    [muMax,~,kN] = maxRates3(CS(it,2),Qmax,N(it));
    limN(it,2) = N(it)/(kN + N(it));
    if T(it) <= mT(it,2)
        limT(it,2) = exp(-(abs(T(it)-mT(it,2))/CA.theta1)^2);
    else
        limT(it,2) = exp(-(abs(T(it)-mT(it,2))/CA.theta2)^3);
    end
    limL(it,2) = 1 - exp((-CA.alpha2.*I(it))./muMax);
    % Cyanobacteria
    [~,Qmax] = CellQuota(CS(it,3));
    [muMax,~,kN] = maxRates3(CS(it,3),Qmax,N(it));
    limN(it,3) = N(it)/(kN + N(it));
    T3 = mT(it,3) - 16.43;
    limT(it,3) = 0.022+1./(0.25+exp(3./(T(it)-T3)-0.5)+exp(-(500./(T(it)-T3)-25)));
    omega_lc = 5.*muMax./3600*(0.022+1./(0.25+exp(3./(T(it)-T3) ...
    -0.5)+exp(-(500./(T(it)-T3)-25))));
    limL(it,3) = (CA.alpha.*I(it))./sqrt(omega_lc.^2+CA.alpha^2.*I(it).^2);
end

% Visualization
time = linspace(1,8640,8640);
red2 = [0.6350 0.0780 0.1840];

figure(6)
% Dinoflagellates
subplot(3,1,1)
plot(time,limN(:,1),'k')
hold on
plot(time,limT(:,1),'k--')
plot(time,limL(:,1),'k:')
plot(time,limN(:,1).*limT(:,1).*limL(:,1),'Color',red2,'LineWidth',1.25)
set(gca,'XTickLabels',[],'Position',[0.085 0.705 0.735 0.26])
ylabel('Growth limitation [-]','FontSize',9)
xlim([0 360*24])

annotation('textbox',[0.09 0.63 0.3 0.3],'String','Din','EdgeColor',...
    'none','FontWeight','normal','FontSize',9)

legend('lim_{\it N}','lim_{\it T}','lim_{\it L}','Total','Location','north')

% Diatoms
subplot(3,1,2)
plot(time,limN(:,2),'k')
hold on
plot(time,limT(:,2),'k--')
plot(time,limL(:,2),'k:')
plot(time,limN(:,2).*limT(:,2).*limL(:,2),'Color',red2,'LineWidth',1.25)
set(gca,'XTickLabels',[],'Position',[0.085 0.39 0.735 0.26])
ylabel('Growth limitation [-]','FontSize',9)
xlim([0 360*24])

annotation('textbox',[0.09 0.315 0.3 0.3],'String','Dia','EdgeColor',...
    'none','FontWeight','normal','FontSize',9)

% Cyanobacteria
subplot(3,1,3)
plot(time,limN(:,3),'k')
hold on
plot(time,limT(:,3),'k--')
plot(time,limL(:,3),'k:')
plot(time,limN(:,3).*limT(:,3).*limL(:,3),'Color',red2,'LineWidth',1.25)
set(gca,'Position',[0.085 0.075 0.725 0.26])
ylabel('Growth limitation [-]','FontSize',9)
xlim([0 24*360])
xticks([15*24 45*24 75*24 105*24 135*24 165*24 195*24 225*24 255*24 285*24 315*24 345*24])
xticklabels({'J','F','M','A','M','J','J','A','S','O','N','D'})
xtickangle(0)

annotation('textbox',[0.09 0.0 0.3 0.3],'String','Cya','EdgeColor',...
    'none','FontWeight','normal','FontSize',9)

%% save figure
pause(n)
fig = figure(6);
fig.Units = 'centimeters';
fig.Position = [0 0 12.7 12.0];
figureName = '../Output_Plots/FigS6.png';
exportgraphics(fig,figureName,'Resolution',1200)

%% Fig. S7: seasonality of Topt
yellow2 = [1 0.6 0];
gray2 = [0.5 0.5 0.5];
time = 1:1:24*360;
yrmTopt = CA.yrmTopt;

figure(7)
% Dinoflagellates
subplot(3,1,1)
yyaxis right
plot(time,CA.temp(1:8640),'Color',gray2,'LineWidth',1)
set(gca,'YColor',gray2)
ylabel('{\it T}_{env} [°C]','FontSize',9)

yyaxis left
plot(time,yrmTopt(:,1)-yrmTopt(1,1),'color',yellow2,'LineWidth',1.1)
set(gca,'XTickLabels',[],'Position',[0.105 0.7 0.81 0.27],'YColor',yellow2)
ylabel('Change in {\it T}_{opt} [°C]','FontSize',9)
xlim([0 24*360])
xticks([15*24 45*24 75*24 105*24 135*24 165*24 195*24 225*24 255*24 285*24 315*24 345*24])

annotation('textbox',[0.105 0.82 0.15 0.15],'String','Dinoflagellates','Color','k','EdgeColor',...
    'none','FontWeight','normal','FontSize',9)

% Diatoms
subplot(3,1,2)
yyaxis right
plot(time,CA.temp(1:8640),'Color',gray2,'LineWidth',1)
set(gca,'YColor',gray2)
ylabel('{\it T}_{env} [°C]','FontSize',9)

yyaxis left
plot(time,yrmTopt(:,2)-yrmTopt(1,2),'-r','LineWidth',1.1)
set(gca,'XTickLabels',[],'Position',[0.105 0.385 0.81 0.27],'YColor','r')
ylabel('Change in {\it T}_{opt} [°C]','FontSize',9)
xlim([0 24*360])
xticks([15*24 45*24 75*24 105*24 135*24 165*24 195*24 225*24 255*24 285*24 315*24 345*24])

annotation('textbox',[0.105 0.505 0.15 0.15],'String','Diatoms','Color','k','EdgeColor',...
    'none','FontWeight','normal','FontSize',9)

% Cyanobacteria
subplot(3,1,3)
yyaxis right
plot(time,CA.temp(1:8640),'Color',gray2,'LineWidth',1)
set(gca,'YColor',gray2)
ylabel('{\it T}_{env} [°C]','FontSize',9)

yyaxis left
plot(time,yrmTopt(:,3)-yrmTopt(1,3),'-b','LineWidth',1.1)
set(gca,'Position',[0.105 0.07 0.81 0.27],'YColor','b')
ylabel('Change in {\it T}_{opt} [°C]','FontSize',9)
ylim([-0.08 0.02])
xlim([0 24*360])
xticks([15*24 45*24 75*24 105*24 135*24 165*24 195*24 225*24 255*24 285*24 315*24 345*24])
xticklabels({'J','F','M','A','M','J','J','A','S','O','N','D'})
xtickangle(0)

annotation('textbox',[0.105 0.19 0.15 0.15],'String','Cyanobacteria','Color','k','EdgeColor',...
    'none','FontWeight','normal','FontSize',9)

%% save figure
pause(n)
fig = figure(7);
fig.Units = 'centimeters';
fig.Position = [0 0 12.7 12.7];
figureName = '../Output_Plots/FigS7.png';
exportgraphics(fig,figureName,'Resolution',1200)

%% Figs. S8 and S9: load files
CA_din = load('../Output_Files/CA_din_vars.mat');
CA_dia = load('../Output_Files/CA_dia_vars.mat');
WA_din = load('../Output_Files/WA_din_vars.mat');
WA_dia = load('../Output_Files/WA_dia_vars.mat');

%% Average optimum temperatures
Topt = cell(2,2);
% CA
Topt{1,1} = CA_din.Topt{1};
Topt{2,1} = CA_dia.Topt{2};
% WA
Topt{1,2} = WA_din.Topt{1};
Topt{2,2} = WA_dia.Topt{2};

meanTopt = zeros(2,2);
meanTopt(1,1) = mean(Topt{1,1});
meanTopt(2,1) = mean(Topt{2,1});
meanTopt(1,2) = mean(Topt{1,2});
meanTopt(2,2) = mean(Topt{2,2});

%% Define colors
gray1 = [82/255 78/255 73/255];
gray2 = [0.1 0.1 0.1];
red2 = [235/255 94/255 40/255];
blue1 = [147/255 141/255 130/255];
blue2 = [217/255 211/255 200/255];

%% Figure S8 (dinoflagellates)
% Extract biomass of dinoflagellate growing stages during the last simulation 
% create time array
time = 1:1:24*360;

figure(8)

% Plot seasonal biomass of growing stages for CA
subplot(2,2,1)
plot(time,CA_din.CA_P(:,1),'color',blue1,'LineWidth',1.25)
hold on
plot(time,CA_din.N(end-360*24+1:end,1),'--k','LineWidth',0.7)
plot(time,CA_din.CA_P(:,1),'color',blue1,'LineWidth',1.25)
ylabel('Biomass [mmol N m^{-3}]','FontSize',9)
set(gca,'XTickLabels',[],'Position',[0.075 0.56 0.355 0.4])
xticks([15*24 45*24 75*24 105*24 135*24 165*24 195*24 225*24 255*24 285*24 315*24 345*24])
xlim([0 24*360])
legend('Dinoflag.','Nitrogen','Location','southeast')
annotation('textbox',[0.37 0.628 0.5 0.3],'String','CA','Color','k','EdgeColor',...
   'none','FontSize',9,'FontWeight','normal')

% Plot seasonal biomass of growing stages for WA
subplot(2,2,3)
plot(time,WA_din.WA_P(:,1),'color',red2,'LineWidth',1.25)
hold on
plot(time,WA_din.N(end-360*24+1:end,1),'--k','LineWidth',0.7)
plot(time,WA_din.WA_P(:,1),'color',red2,'LineWidth',1.25)
set(gca,'Position',[0.075 0.1013 0.355 0.4])
ylabel('Biomass [mmol N m^{-3}]','FontSize',9)
xlim([0 24*360])
xticks([15*24 45*24 75*24 105*24 135*24 165*24 195*24 225*24 255*24 285*24 315*24 345*24])
xticklabels({'J','F','M','A','M','J','J','A','S','O','N','D'})
xtickangle(0)
legend('Dinoflag.','Nitrogen','Location','southeast')
annotation('textbox',[0.37 0.1693 0.5 0.3],'String','WA','Color','k','EdgeColor',...
   'none','FontSize',9,'FontWeight','normal')

% Plot Topt
subplot(2,2,[2,4])

% Create y-axis on the right to plot initial Topt
yyaxis right
ax = gca;
h2 = histogram(10.8,'FaceColor',gray1,'FaceAlpha',0.7,'Normalization','probability');
ax.YColor = gray1;
h2.BinWidth = 0.18;
h2.LineWidth = 0.3;
hold on

% Create y-axis on the left to plot Topt distribution after CA and WA
yyaxis left
ax = gca;
histogram(Topt{1,2},'BinWidth',0.18,'FaceAlpha',0.69,'FaceColor',red2,'Normalization','probability','LineWidth',0.3)
hold on
histogram(Topt{1,1},'BinWidth',0.18,'FaceAlpha',0.5,'FaceColor',blue2,'Normalization','probability','LineWidth',0.3,'EdgeColor',gray2)
dis = histogram(Topt{1,2},'BinWidth',0.18,'FaceAlpha',0.01,'FaceColor',red2,'Normalization','probability','LineWidth',0.3);
dis.Annotation.LegendInformation.IconDisplayStyle = 'off';
ax.YColor = 'k';
ax.Position = [0.55 0.1 0.395 0.86];
ylabel('Relative biomass','FontSize',9);
xlim([3 12])
xticks([3 6 9 12])
xticklabels({'3','6','9','12'})
xlabel('Optimum temperature [°C]','FontSize',9)

l = legend('WA','CA','Initial','Location','north');
l.AutoUpdate = 'off';
l.PlotChildren = l.PlotChildren([3,2,1]);
l.Location = 'northwest';
l.FontSize = 7;
l.Position = [0.605 0.9018 0 0];
l.ItemTokenSize = [15 5];

%% save figure
pause(n)
fig = figure(8);
fig.Units = 'centimeters';
fig.Position = [0 0 12.7 9];
figureName = '../Output_Plots/FigS8.png';
exportgraphics(fig,figureName,'Resolution',1200)

%% Figure S9 (diatoms)
% Extract biomass of dinoflagellate growing stages during the last simulation 
% create time array
time = 1:1:24*360;

figure(9)

% Plot seasonal biomass of growing stages for CA
subplot(2,2,1)
plot(time,CA_dia.CA_P(:,2),'color',blue1,'LineWidth',1.25)
hold on
plot(time,CA_dia.N(end-360*24+1:end,1),'--k','LineWidth',0.7)
plot(time,CA_dia.CA_P(:,2),'color',blue1,'LineWidth',1.25)
ylabel('Biomass [mmol N m^{-3}]','FontSize',9)
set(gca,'XTickLabels',[],'Position',[0.075 0.56 0.355 0.4])
xticks([15*24 45*24 75*24 105*24 135*24 165*24 195*24 225*24 255*24 285*24 315*24 345*24])
xlim([0 24*360])
legend('Diatoms','Nitrogen','Location','northeast')
annotation('textbox',[0.08 0.4937 0.5 0.3],'String','CA','Color','k','EdgeColor',...
   'none','FontSize',9,'FontWeight','normal')

% Plot seasonal biomass of growing stages for WA
subplot(2,2,3)
plot(time,WA_dia.WA_P(:,2),'color',red2,'LineWidth',1.25)
hold on
plot(time,WA_dia.N(end-360*24+1:end,1),'--k','LineWidth',0.7)
plot(time,WA_dia.WA_P(:,2),'color',red2,'LineWidth',1.25)
set(gca,'Position',[0.075 0.1013 0.3575 0.4])
ylabel('Biomass [mmol N m^{-3}]','FontSize',9)
xlim([0 24*360])
xticks([15*24 45*24 75*24 105*24 135*24 165*24 195*24 225*24 255*24 285*24 315*24 345*24])
xticklabels({'J','F','M','A','M','J','J','A','S','O','N','D'})
xtickangle(0)
legend('Diatoms','Nitrogen','Location','northeast')
annotation('textbox',[0.08 0.0355 0.5 0.3],'String','WA','Color','k','EdgeColor',...
   'none','FontSize',9,'FontWeight','normal')

% Plot Topt
subplot(2,2,[2,4])

% Create y-axis on the right to plot initial Topt
yyaxis right
ax = gca;
h2 = histogram(12.0,'FaceColor',gray1,'FaceAlpha',0.7,'Normalization','probability');
ax.YColor = gray1;
h2.BinWidth = 0.21;
h2.LineWidth = 0.3;
hold on

% Create y-axis on the left to plot Topt distribution after CA and WA
yyaxis left
ax = gca;
histogram(Topt{2,2},'BinWidth',0.21,'FaceAlpha',0.69,'FaceColor',red2,'Normalization','probability','LineWidth',0.3)
hold on
histogram(Topt{2,1},'BinWidth',0.21,'FaceAlpha',0.5,'FaceColor',blue2,'Normalization','probability','LineWidth',0.3,'EdgeColor',gray2)
dis = histogram(Topt{2,2},'BinWidth',0.21,'FaceAlpha',0.01,'FaceColor',red2,'Normalization','probability','LineWidth',0.3);
dis.Annotation.LegendInformation.IconDisplayStyle = 'off';
ax.YColor = 'k';
ax.Position = [0.55 0.1 0.395 0.86];
ylabel('Relative biomass','FontSize',9);
xlim([11.5 22])
xl = xlabel('Optimum temperature [°C]','FontSize',9);

fig = figure(9);
fig.Units = 'centimeters';
fig.Position = [0 0 12.7 9];

l = legend('WA','CA','Initial','Location','north');
l.AutoUpdate = 'off';
l.PlotChildren = l.PlotChildren([3,2,1]);
l.Location = 'northwest';
l.FontSize = 7;
l.Position = [0.605 0.90195 0 0];
l.ItemTokenSize = [15 5];

%% save figure
pause(n)
fig = figure(9);
fig.Units = 'centimeters';
fig.Position = [0 0 12.7 9];
figureName = '../Output_Plots/FigS9.png';
exportgraphics(fig,figureName,'Resolution',1200)

%% Fig. S10: Topt trait distribution
% Create annual Topt trait distribution
Topt_annual_CA = CA.Topt_annual;
Topt_annual_WA = WA.Topt_annual;
y = 0:0.1:35;
y2 = linspace(0,35,350);
x = linspace(1,200,200);
traitDist = zeros(length(y2),200,3);

for iSpecies = 1:3
    for iYear = 1:100
        for iScenario = 1:4
            if iScenario == 1
                traitDist(:,iYear,iSpecies) = histcounts(Topt_annual_CA{iYear,iSpecies},y,'Normalization','probability')';
            elseif iScenario == 2
                traitDist(:,iYear+100,iSpecies) = histcounts(Topt_annual_WA{iYear,iSpecies},y,'Normalization','probability')';
            end
        end
    end
end

% Create color map
vec = [0; 0.0001; 0.1; 0.25; 0.6; 0.8; 1];
clrs = [1 1 1; 1 0.95 0.8; 0.9290 0.6940 0.1250; 0.8500 0.3250 0.0980; 0.6350 0.0780 0.1840; 0.4940 0.1840 0.5560; 0 0 0.5];
N = 1000;
map = interp1(vec,clrs,linspace(0,1,N));

% Create array with annual mean Topt
mTopt_h = [CA.mTopt; WA.mTopt];
mTopt = zeros(200,3);
x2 = linspace(1,200,1728000);

for iSpecies = 1:3
    for iYear = 1:200
        mTopt(iYear,iSpecies) = mean(mTopt_h((iYear-1)*8640+1:iYear*8640,iSpecies));
    end
end

% Visualization
figure(10)

% Dinoflagellates
subplot(3,1,1)
levels = [0 0.01 0.1 0.5 1.25 2.5 3.75 5];
[~,h] = contourf(x,y2,traitDist(:,:,1)*100,levels);
hold on
plot(x,mTopt(:,1),'w--')
plot([100 100],[0 15],'k--')
set(gca,'XTickLabels',[],'Position',[0.09 0.71 0.84 0.28])
set(h,'LineColor','none')
ylim([0 15])

colormap(map);
c = colorbar();
c.Ticks = [0 1 2 3 4 5];
c.TickLabels = {'0' '1' '2' '3' '4' '5'};
c.Label.String = '% of biomass';
c.Label.FontSize = 9;

annotation('textbox',[0.23 0.825 0.15 0.15],'String','CA','EdgeColor',...
    'none','FontWeight','normal','FontSize',9)

annotation('textbox',[0.59 0.825 0.15 0.15],'String','WA','EdgeColor',...
    'none','FontWeight','normal','FontSize',9)

annotation('textbox',[0.095 0.62 0.15 0.15],'String','Dinoflag.','EdgeColor',...
    'none','FontWeight','normal','FontSize',9)

% Diatoms
subplot(3,1,2);
[~,h] = contourf(x,y2,traitDist(:,:,2)*100,levels);
hold on
plot(x,mTopt(:,2),'w--')
plot([100 100],[0 20],'k--')
set(gca,'XTickLabels',[],'Position',[0.09 0.4 0.84 0.28])
yl = ylabel('Optimum temperature [°C]','FontSize',11);
yl.Position = [-15 12];
ylim([5 20])
set(h,'LineColor','none')

colormap(map);
c = colorbar();
c.Ticks = [0 1 2 3 4 5];
c.TickLabels = {'0' '1' '2' '3' '4' '5'};
c.Label.String = '% of biomass';
c.Label.FontSize = 9;

annotation('textbox',[0.095 0.31 0.15 0.15],'String','Diatoms','EdgeColor',...
    'none','FontWeight','normal','FontSize',9)

% Cyanobacteria
subplot(3,1,3);
[~,h] = contourf(x,y2,traitDist(:,:,3)*100,levels);
hold on
plot(x,mTopt(:,3),'w--')
plot([100 100],[20 35],'k--')
xlabel('Time [yr]','FontSize',11)
ylim([20 35])
set(gca,'Position',[0.09 0.09 0.86 0.28])
set(h,'LineColor','none')

colormap(map);
c = colorbar();
c.Ticks = [0 1 2 3 4 5];
c.TickLabels = {'0' '1' '2' '3' '4' '5'};
c.Label.String = '% of biomass';
c.Label.FontSize = 9;

annotation('textbox',[0.095 0.0 0.15 0.15],'String','Cyanobacteria','EdgeColor',...
    'none','FontWeight','normal','FontSize',9)

%% save figure
pause(n)
fig = figure(10);
fig.Units = 'centimeters';
fig.Position = [0 0 12.7 12.7];
figureName = '../Output_Plots/FigS10.png';
exportgraphics(fig,figureName,'Resolution',1200)

%% Fig. S11: evolution of Topt with and without resuspension
gray2 = [0.5 0.5 0.5];
yellow2 = [1 0.6 0];
blue2 = [0 0.4470 0.7410];
red2 = [0.6350 0.0780 0.1840];
yellow3 = [0.8500 0.3250 0.0980];

mTopt = [CA.mTopt; WA.mTopt];
mTopt2 = [CAR.mTopt; WAR.mTopt];
time = linspace(1,200,200);

% Create arrays of annual mean Topt with and without resuspension
mToptYear = zeros(200,3);    % Without resuspension
mToptYear2 = zeros(200,3);   % With resuspension
for iYear = 1:200
    mToptYear(iYear,:) = mean(mTopt(iYear*360*24-360*24+1:iYear*360*24,:),1);
    mToptYear2(iYear,:) = mean(mTopt2(iYear*360*24-360*24+1:iYear*360*24,:),1);
end

mToptYear = movmean(mToptYear,10,1);
mToptYear2 = movmean(mToptYear2,10,1);

% Visualization
figure(11)
plot(time,mToptYear(:,1)-mToptYear(1,1),'Color',yellow2,'LineWidth',1)
hold on
plot(time,mToptYear2(:,1)-mToptYear2(1,1),'--','Color',yellow2,'LineWidth',1)
plot(time,mToptYear(:,2)-mToptYear(1,2),'r','LineWidth',1)
plot(time,mToptYear2(:,2)-mToptYear2(1,2),'--r','LineWidth',1)
plot(time,mToptYear(:,3)-mToptYear(1,3),'b','LineWidth',1)
plot(time,mToptYear2(:,3)-mToptYear2(1,3),'--b','LineWidth',1)
yl = ylabel('Change in {\it T}_{opt} [°C]','FontSize',11);
yl.Position(1) = yl.Position(1) - 0.5;
yl.Position(2) = yl.Position(2) + 0.3;
xlabel('Time [yr]','FontSize',11);
plot([100 100],[-6 1],'k--','LineWidth',0.75)

annotation('textbox',[0.2 0.76 0.15 0.15],'String','Control','EdgeColor',...
    'none','FontWeight','normal','FontSize',9)

annotation('textbox',[0.59 0.76 0.15 0.15],'String','Warming','EdgeColor',...
    'none','FontWeight','normal','FontSize',9)

l = legend('Dinoflagellates','Resuspension','Diatoms','Resuspension','Cyanobacteria','Resuspension','Location','east');
l.FontSize = 8;

%% save figure
pause(n)
fig = figure(11);
fig.Units = 'centimeters';
fig.Position = [0 0 12.7 8];
figureName = '../Output_Plots/FigS11.png';
exportgraphics(fig,figureName,'Resolution',1200)

%% Fig. S12: Topt trait distribution for additional simulations with only dinoflagellates and diatoms
% Create annual Topt trait distribution
Topt_annual_CA_din = CA_din.Topt_annual;
Topt_annual_CA_dia = CA_dia.Topt_annual;
Topt_annual_WA_din = WA_din.Topt_annual;
Topt_annual_WA_dia = WA_dia.Topt_annual;

y = 0:0.1:35;
y2 = linspace(0,35,350);
x = linspace(1,200,200);
traitDist = zeros(length(y2),200,3);

for iSpecies = 1:2
    for iYear = 1:100
        for iScenario = 1:2
            if iSpecies == 1
                if iScenario == 1
                    traitDist(:,iYear,iSpecies) = histcounts(Topt_annual_CA_din{iYear,iSpecies},y,'Normalization','probability')';
                elseif iScenario == 2
                    traitDist(:,iYear+100,iSpecies) = histcounts(Topt_annual_WA_din{iYear,iSpecies},y,'Normalization','probability')';
                end
            else
                if iScenario == 1
                    traitDist(:,iYear,iSpecies) = histcounts(Topt_annual_CA_dia{iYear,iSpecies},y,'Normalization','probability')';
                 elseif iScenario == 2
                    traitDist(:,iYear+100,iSpecies) = histcounts(Topt_annual_WA_dia{iYear,iSpecies},y,'Normalization','probability')';
                end
            end
        end
    end
end

% Create color map
vec = [0; 0.0001; 0.1; 0.25; 0.6; 0.8; 1];
clrs = [1 1 1; 1 0.95 0.8; 0.9290 0.6940 0.1250; 0.8500 0.3250 0.0980; 0.6350 0.0780 0.1840; 0.4940 0.1840 0.5560; 0 0 0.5];
N = 1000;
map = interp1(vec,clrs,linspace(0,1,N));

% Create arrays with annual mean Topt
mTopt_din = [CA_din.mTopt; WA_din.mTopt];
mTopt_dia = [CA_dia.mTopt; WA_dia.mTopt];
mTopt = zeros(200,2);

for iSpecies = 1:2
    for iYear = 1:200
        if iSpecies == 1
            mTopt(iYear,iSpecies) = mean(mTopt_din((iYear-1)*8640+1:iYear*8640,iSpecies));
        else
            mTopt(iYear,iSpecies) = mean(mTopt_dia((iYear-1)*8640+1:iYear*8640,iSpecies));
        end
    end
end

% Visualization
figure(12)

% Dinoflagellates
subplot(2,1,1)
levels = [0 0.01 0.1 0.5 1.25 2.5 3.75 5];
[~,h] = contourf(x,y2,traitDist(:,:,1)*100,levels);
hold on
plot(x,mTopt(:,1),'w--')
plot([100 100],[0 15],'k--')
set(gca,'XTickLabels',[],'Position',[0.09 0.71 0.84 0.28])
set(h,'LineColor','none')
ylim([0 15])

colormap(map);
c = colorbar();
c.Ticks = [0 1 2 3 4 5];
c.TickLabels = {'0' '1' '2' '3' '4' '5'};
c.Label.String = '% of biomass';
c.Label.FontSize = 9;

annotation('textbox',[0.23 0.825 0.15 0.15],'String','CA','EdgeColor',...
    'none','FontWeight','normal','FontSize',9)

annotation('textbox',[0.59 0.825 0.15 0.15],'String','WA','EdgeColor',...
    'none','FontWeight','normal','FontSize',9)

annotation('textbox',[0.095 0.63 0.15 0.15],'String','Dinoflag.','EdgeColor',...
    'none','FontWeight','normal','FontSize',9)

% Diatoms
subplot(2,1,2);
[~,h] = contourf(x,y2,traitDist(:,:,2)*100,levels);
hold on
plot(x,mTopt(:,2),'w--')
plot([100 100],[5 25],'k--')
set(gca,'Position',[0.09 0.4 0.84 0.28])
yl = ylabel('Optimum temperature [°C]','FontSize',11);
yl.Position = [-15 25.7];
ylim([10 25])
set(h,'LineColor','none')
xlabel('Time [yr]','FontSize',11)

colormap(map);
c = colorbar();
c.Ticks = [0 1 2 3 4 5];
c.TickLabels = {'0' '1' '2' '3' '4' '5'};
c.Label.String = '% of biomass';
c.Label.FontSize = 9;

annotation('textbox',[0.095 0.515 0.15 0.15],'String','Diatoms','EdgeColor',...
    'none','FontWeight','normal','FontSize',9)

%% save figure
pause(n)
fig = figure(12);
fig.Units = 'centimeters';
fig.Position = [0 0 12.7 12.7];
figureName = '../Output_Plots/FigS12.png';
exportgraphics(fig,figureName,'Resolution',1200)
