function[V] = Mass2Volume(b)

% function to calculate cell volume from cell biomass

% input:
% - b: cell biomass [mmol N]
% output:
% - V: cell volume [mu m^3]

% cellular carbon content [mmol C] (Redfield, 1985)
b_C = 106*b/16;
% cell volume [mu m^3] (Menten-Deuer and Lessard, 2000)
V = (10^(12)*b_C./18).^(1/0.94);