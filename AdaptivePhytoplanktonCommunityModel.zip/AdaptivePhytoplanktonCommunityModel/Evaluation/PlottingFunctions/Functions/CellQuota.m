function[Qmin,Qmax] = CellQuota(b)

% function to calculate minimum and maximum nitrogen cell quotas from
% allometric relations

% input:
% - b: cell biomass [mmol N]
% output:
% - Qmin: minimum nitrogen cell quota [mmol N]
% - Qmax: maximum nitrogen cell quota [mmol N]

% calculate nitrogen quotas
V = Mass2Volume(b);                             % cell volume [mu m^3]
Qmin = 0.032*V.^(0.76);                         % minimum cell quota [pg N] (Ward et al., 2017)
Qmax = 10^(-1.26)*V.^0.93;                      % maximum cell quota [pg N] (Maranon et al, 2013)

% convert results to mmol N
Qmin = 10^(-9)*0.0714*Qmin;                     % minimum cell quota [mmol N]
Qmax = 10^(-9)*0.0714*Qmax;                     % maximum cell quota [mmol N]

