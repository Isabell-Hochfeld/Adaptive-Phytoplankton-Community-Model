%% Figures_Manuscript.m
% Script to create Figs. 2 and 3 from the manuscript

close all
clearvars

n = 2;       % Time to pause execution before saving figures [s] 

%% load files
C = load('../Output_Files/C_vars.mat');
CA = load('../Output_Files/CA_vars.mat');
CAR = load('../Output_Files/CAR_vars.mat');
W = load('../Output_Files/W_vars.mat');
WA = load('../Output_Files/WA_vars.mat');
WAR = load('../Output_Files/WAR_vars.mat');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Fig. 2: BLOOM TIMING & AMPLITUDE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% DINOFLAGELLATES
idx1 = zeros(1,6);      % index of bloom peak
max1 = zeros(1,6);      % amplitude of bloom peak
P11 = zeros(360*24,6);  % biomass of vegetative cells during the last simulation year
%% CA
P11(:,1) = CA.CA_P(:,1);
[max1(1),idx1(1)] = max(P11(:,1));
%% WA
P11(:,2) = WA.WA_P(:,1);
[max1(2),idx1(2)] = max(P11(:,2));
%% CAR
P11(:,3) = CAR.CAR_P(:,1);
[max1(3),idx1(3)] = max(P11(:,3));
%% WAR
P11(:,4) = WAR.WAR_P(:,1);
[max1(4),idx1(4)] = max(P11(:,4));
%% C
P11(:,5) = C.C_P(:,1);
[max1(5),idx1(5)] = max(P11(:,5));
%% W
P11(:,6) = W.W_P(:,1);
[max1(6),idx1(6)] = max(P11(:,6));

%% DIATOMS
idx2 = zeros(2,6);      % index of bloom peak
max2 = zeros(2,6);      % amplitude of bloom peak
P21 = zeros(360*24,6);  % biomass of vegetative cells during the last simulation year
%% CA
P21(:,1) = CA.CA_P(:,2);
% pring bloom
[max2(1,1),idx2(1,1)] = max(P21(1:240*24,1));
% autumn bloom
[max2(2,1),idx2(2,1)] = max(P21(240*24:end,1));
idx2(2,1) = idx2(2,1) + 240*24 - 1;
%% WA
P21(:,2) = WA.WA_P(:,2);
% spring bloom
[max2(1,2),idx2(1,2)] = max(P21(1:240*24,2));
% autumn bloom
[max2(2,2),idx2(2,2)] = max(P21(240*24:end,2));
idx2(2,2) = idx2(2,2) + 240*24 - 1;
%% CAR
P21(:,3) = CAR.CAR_P(:,2);
% spring bloom
[max2(1,3),idx2(1,3)] = max(P21(1:240*24,3));
% autumn bloom
[max2(2,3),idx2(2,3)] = max(P21(240*24:end,3));
idx2(2,3) = idx2(2,3) + 240*24 - 1;
%% WAR
P21(:,4) = WAR.WAR_P(:,2);
% spring bloom
[max2(1,4),idx2(1,4)] = max(P21(1:240*24,4));
% autumn bloom
[max2(2,4),idx2(2,4)] = max(P21(240*24:end,4));
idx2(2,4) = idx2(2,4) + 240*24 - 1;
%% C
P21(:,5) = C.C_P(:,2);
% spring bloom
[max2(1,5),idx2(1,5)] = max(P21(1:240*24,5));
% autumn bloom
[max2(2,5),idx2(2,5)] = max(P21(240*24:end,5));
idx2(2,5) = idx2(2,5) + 240*24 - 1;
%% W
P21(:,6) = W.W_P(:,2);
% spring bloom
[max2(1,6),idx2(1,6)] = max(P21(1:240*24,6));
% autumn bloom
[max2(2,6),idx2(2,6)] = max(P21(240*24:end,6));
idx2(2,6) = idx2(2,6) + 240*24 - 1;

%% cyanobacteria
idx3 = zeros(1,6);       % index of bloom peak
max3 = zeros(1,6);       % amplitude of bloom peak
P3 = zeros(360*24,6);    % biomass of VEG and HET during the last simulation year
%% CA
P3(:,1) = CA.CA_P(:,3);
[max3(1),idx3(1)] = max(P3(:,1));
%% WA
P3(:,2) = WA.WA_P(:,3);
[max3(2),idx3(2)] = max(P3(:,2));
%% CAR
P3(:,3) = CAR.CAR_P(:,3);
[max3(3),idx3(3)] = max(P3(:,3));
%% WAR
P3(:,4) = WAR.WAR_P(:,3);
[max3(4),idx3(4)] = max(P3(:,4));
%% C
P3(:,5) = C.C_P(:,3);
[max3(5),idx3(5)] = max(P3(:,5));
%% W
P3(:,6) = W.W_P(:,3);
[max3(6),idx3(6)] = max(P3(:,6));

%% bloom timing [d]
timing(1,:) = idx1/24;         % dinoflagellates
timing(2,:) = idx2(1,:)/24;    % diatoms spring bloom
timing(3,:) = idx2(2,:)/24;    % diatoms autumn bloom
timing(4,:) = idx3/24;         % cyanobacteria
% rearrange columns: C, W, CA, WA, CAR, WAR
timing = timing(:,[5 6 1 2 3 4]);

%% amplitude [mmol N m^-3]
amplitude(1,:) = max1;         % dinoflagellates
amplitude(2,:) = max2(1,:);    % diatom spring bloom
amplitude(3,:) = max2(2,:);    % diatom autumn bloom
amplitude(4,:) = max3;         % cyanobacteria
% rearrange columns: C, W, CA, WA, CAR, WAR
amplitude = amplitude(:,[5 6 1 2 3 4]);

%% Figure 2
yellow2 = [1 0.6 0];
time = 1:1:24*360;

figure(1)

%% C
subplot(2,3,1)
% plot seasonal biomass of growing stages
plot(time,P11(:,5),'Color',yellow2,'LineWidth',1)
hold on
plot(time,P21(:,5),'r','LineWidth',1)
plot(time,P3(:,5),'b','LineWidth',1)
% set axes
set(gca,'FontSize',9,'XTickLabels',[],'Position',[0.085 0.535 0.29 0.42])
ylabel('Biomass [mmol N m^{-3}]','FontSize',9)
xlim([0 24*360])
ylim([0,2])
xticks([15*24 45*24 75*24 105*24 135*24 165*24 195*24 225*24 255*24 285*24 315*24 345*24])
% create grid
grid on
grid minor
ax = gca;
ax.XAxis.MinorTick = 'on';
ax.XAxis.MinorTickValues = ax.XAxis.Limits(1):15*24:ax.XAxis.Limits(2);
ax.GridAlpha = 0.45;
% create annotation
annotation('textbox',[0.33 0.6677 0.15 0.3],'String','C','EdgeColor',...
    'none','FontWeight','normal','FontSize',9)
% create legend
l = legend('Dinoflagellates','Diatoms','Cyanobacteria','Location','northwest');
l.FontSize = 7.25;
l.ItemTokenSize = [17 5];

%% W
subplot(2,3,4)
% plot seasonal biomass of growing stages
plot(time,P11(:,6),'Color',yellow2,'LineWidth',1)
hold on
plot(time,P21(:,6),'r','LineWidth',1)
plot(time,P3(:,6),'b','LineWidth',1)
% plot dashed lines to indicate bloom peaks in C
plot([idx1(5) idx1(5)],[0 2.5],'--','Color',yellow2,'LineWidth',0.75)
plot([idx2(1,5) idx2(1,5)],[0 2.5],'r--','LineWidth',0.75)
plot([idx2(2,5) idx2(2,5)],[0 2.5],'r--','LineWidth',0.75)
plot([idx3(5) idx3(5)],[0 2.5],'b--','LineWidth',0.75)
% set axes
set(gca,'FontSize',9,'XTickLabels',[],'Position',[0.085 0.06 0.29 0.42])
ylabel('Biomass [mmol N m^{-3}]','FontSize',9)
xlim([0 24*360])
ylim([0,2])
xticks([15*24 45*24 75*24 105*24 135*24 165*24 195*24 225*24 255*24 285*24 315*24 345*24])
xticklabels({'J','F','M','A','M','J','J','A','S','O','N','D'})
xtickangle(0)
% create grid
grid on
grid minor
ax = gca;
ax.XAxis.MinorTick = 'on';
ax.XAxis.MinorTickValues = ax.XAxis.Limits(1):15*24:ax.XAxis.Limits(2);
ax.GridAlpha = 0.45;
% create annotation
annotation('textbox',[0.33 0.1928 0.15 0.3],'String','W','EdgeColor',...
    'none','FontWeight','normal','FontSize',9)

%% CA
subplot(2,3,2)
% plot seasonal biomass of growing stages
plot(time,P11(:,1),'Color',yellow2,'LineWidth',1)
hold on
plot(time,P21(:,1),'r','LineWidth',1)
plot(time,P3(:,1),'b','LineWidth',1)
% set axes
set(gca,'FontSize',9,'XTickLabels',[],'YTickLabels',[],'Position',[0.3925 0.535 0.29 0.42])
xlim([0 24*360])
ylim([0,2])
xticks([15*24 45*24 75*24 105*24 135*24 165*24 195*24 225*24 255*24 285*24 315*24 345*24])
% create grid
grid on
grid minor
ax = gca;
ax.XAxis.MinorTick = 'on';
ax.XAxis.MinorTickValues = ax.XAxis.Limits(1):15*24:ax.XAxis.Limits(2);
ax.GridAlpha = 0.45;
% create annotation
annotation('textbox',[0.622 0.6677 0.15 0.3],'String','CA','EdgeColor',...
    'none','FontWeight','normal','FontSize',9)

%% WA
subplot(2,3,5)
% plot seasonal biomass of growing stages
plot(time,P11(:,2),'Color',yellow2,'LineWidth',1)
hold on
plot(time,P21(:,2),'r','LineWidth',1)
plot(time,P3(:,2),'b','LineWidth',1)
% plot dashed lines to indicate bloom peaks in CA
plot([idx1(1) idx1(1)],[0 2.5],'--','Color',yellow2,'LineWidth',0.75)
plot([idx2(1,1) idx2(1,1)],[0 2.5],'r--','LineWidth',0.75)
plot([idx2(2,1) idx2(2,1)],[0 2.5],'r--','LineWidth',0.75)
plot([idx3(1) idx3(1)],[0 2.5],'b--','LineWidth',0.75)
% set axes
set(gca,'FontSize',9,'XTickLabels',[],'YTickLabels',[],'Position',[0.3925 0.06 0.29 0.42])
xlim([0 24*360])
ylim([0,2])
xticks([15*24 45*24 75*24 105*24 135*24 165*24 195*24 225*24 255*24 285*24 315*24 345*24])
xticklabels({'J','F','M','A','M','J','J','A','S','O','N','D'})
xtickangle(0)
% create grid
grid on
grid minor
ax = gca;
ax.XAxis.MinorTick = 'on';
ax.XAxis.MinorTickValues = ax.XAxis.Limits(1):15*24:ax.XAxis.Limits(2);
ax.GridAlpha = 0.45;
% create annotation
annotation('textbox',[0.622 0.1928 0.15 0.3],'String','WA','EdgeColor',...
    'none','FontWeight','normal','FontSize',9)

%% CAR
subplot(2,3,3)
% plot seasonal biomass of growing stages
plot(time,P11(:,3),'Color',yellow2,'LineWidth',1)
hold on
plot(time,P21(:,3),'r','LineWidth',1)
plot(time,P3(:,3),'b','LineWidth',1)
% set axes
set(gca,'FontSize',9,'XTickLabels',[],'YTickLabels',[],'Position',[0.7 0.535 0.29 0.42])
xlim([0 24*360])
ylim([0,2])
xticks([15*24 45*24 75*24 105*24 135*24 165*24 195*24 225*24 255*24 285*24 315*24 345*24])
% create grid
grid on
grid minor
ax = gca;
ax.XAxis.MinorTick = 'on';
ax.XAxis.MinorTickValues = ax.XAxis.Limits(1):15*24:ax.XAxis.Limits(2);
ax.GridAlpha = 0.45;
% create annotation
annotation('textbox',[0.913 0.6677 0.15 0.3],'String','CAR','EdgeColor',...
    'none','FontWeight','normal','FontSize',9)

%% WAR
subplot(2,3,6)
% plot seasonal biomass of growing stages
plot(time,P11(:,4),'Color',yellow2,'LineWidth',1)
hold on
plot(time,P21(:,4),'r','LineWidth',1)
plot(time,P3(:,4),'b','LineWidth',1)
% plot dashed lines to indicate bloom peaks in CAR
plot([idx1(3) idx1(3)],[0 2.5],'--','Color',yellow2,'LineWidth',0.75)
plot([idx2(1,3) idx2(1,3)],[0 2.5],'r--','LineWidth',0.75)
plot([idx2(2,3) idx2(2,3)],[0 2.5],'r--','LineWidth',0.75)
plot([idx3(3) idx3(3)],[0 2.5],'b--','LineWidth',0.75)
% set axes
set(gca,'FontSize',9,'XTickLabels',[],'YTickLabels',[],'Position',[0.7 0.06 0.29 0.42])
xlim([0 24*360])
ylim([0,2])
xticks([15*24 45*24 75*24 105*24 135*24 165*24 195*24 225*24 255*24 285*24 315*24 345*24])
xticklabels({'J','F','M','A','M','J','J','A','S','O','N','D'})
xtickangle(0)
% create grid
grid on
grid minor
ax = gca;
ax.XAxis.MinorTick = 'on';
ax.XAxis.MinorTickValues = ax.XAxis.Limits(1):15*24:ax.XAxis.Limits(2);
ax.GridAlpha = 0.45;
% create annotation
annotation('textbox',[0.913 0.1928 0.15 0.3],'String','WAR','EdgeColor',...
    'none','FontWeight','normal','FontSize',9)

%% save figure
pause(n)
fig = figure(1);
fig.Units = 'centimeters';
fig.Position = [0 0 12.7 7];
figureName = '../Output_Plots/Fig2.tiff';
exportgraphics(fig,figureName,'Resolution',1200)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Fig. 3: EVOLUTION IN THE OPTIMUM TEMPERATURE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% optimum temperatures
Topt = cell(4,3);
% CA
Topt{1,1} = CA.Topt{1};
Topt{1,2} = CA.Topt{2};
Topt{1,3} = CA.Topt{3};
% WA
Topt{2,1} = WA.Topt{1};
Topt{2,2} = WA.Topt{2};
Topt{2,3} = WA.Topt{3};
% CAR
Topt{3,1} = CAR.Topt{1};
Topt{3,2} = CAR.Topt{2};
Topt{3,3} = CAR.Topt{3};
% WAR
Topt{4,1} = WAR.Topt{1};
Topt{4,2} = WAR.Topt{2};
Topt{4,3} = WAR.Topt{3};

%% Figure 3
gray1 = [82/255 78/255 73/255];
red2 = [235/255 94/255 40/255];
blue2 = [217/255 211/255 200/255];
gray2 = [0.1 0.1 0.1];
figure(2)

%% dinoflagellates
% no resuspension
subplot(2,3,1)

% create y-axis on the right to plot initial Topt
yyaxis right
ax = gca;
ax.FontSize = 8;
h2 = histogram(10.8,'FaceColor',gray1,'FaceAlpha',0.7,'Normalization','probability');
ax.YColor = gray1;
h2.BinWidth = 0.2;
h2.LineWidth = 0.3;
hold on

% create y-axis on the left to plot Topt distribution after CA and WA
yyaxis left
ax = gca;
histogram(Topt{2,1},'BinWidth',0.2,'FaceAlpha',0.69,'FaceColor',red2,'Normalization','probability','LineWidth',0.3)
hold on
histogram(Topt{1,1},'BinWidth',0.2,'FaceAlpha',0.5,'FaceColor',blue2,'Normalization','probability','LineWidth',0.3,'EdgeColor',gray2)
dis = histogram(Topt{2,1},'BinWidth',0.2,'FaceAlpha',0.01,'FaceColor',red2,'Normalization','probability','LineWidth',0.3);
dis.Annotation.LegendInformation.IconDisplayStyle = 'off';
ax.YColor = 'k';
ax.Position = [0.071 0.56 0.23 0.4];
ylabel('Relative biomass','FontSize',8)
xlim([2 12])
ylim([0 0.12])
ax.XTickLabels = [];
ax.YTickLabels = [];
yticks([0 0.04 0.08 0.12])
yticklabels({'0','0.04','0.08','0.12','0.14'})
annotation('textbox',[0.065 0.669 0.5 0.3],'String','Din.','Color','k','EdgeColor',...
    'none','FontSize',8,'FontWeight','normal')

l = legend('WA','CA','Initial','Location','north');
l.AutoUpdate = 'off';
l.PlotChildren = l.PlotChildren([3,2,1]);
l.Location = 'northeast';
l.FontSize = 6.5;
l.Position = [0.2475 0.8948 0 0];
l.ItemTokenSize = [15 5];

%% resuspension
subplot(2,3,4)

% create y-axis on the right to plot initial Topt
yyaxis right
ax = gca;
set(gca,'FontSize',8)
h2 = histogram(10.8,'FaceColor',gray1,'FaceAlpha',0.7,'Normalization','probability');
ax.YColor = gray1;
h2.BinWidth = 0.2;
h2.LineWidth = 0.3;
hold on

% create y-axis on the left to plot Topt distribution after CAR and WAR
yyaxis left
ax = gca;
histogram(Topt{4,1},'BinWidth',0.2,'FaceAlpha',0.69,'FaceColor',red2,'Normalization','probability','LineWidth',0.3)
hold on
histogram(Topt{3,1},'BinWidth',0.2,'FaceAlpha',0.5,'FaceColor',blue2,'Normalization','probability','LineWidth',0.3,'EdgeColor',gray2)
dis = histogram(Topt{4,1},'BinWidth',0.2,'FaceAlpha',0.01,'FaceColor',red2,'Normalization','probability','LineWidth',0.3);
dis.Annotation.LegendInformation.IconDisplayStyle = 'off';
ax.YColor = 'k';
ax.Position = [0.071 0.1 0.23 0.4];
xlabel('Optimum temperature [°C]','FontSize',8)
ylabel('Relative biomass','FontSize',8)
xlim([2 12])
ylim([0 0.12])
ax.YTickLabels = [];
yticks([0 0.04 0.08 0.12])
yticklabels({'0','0.04','0.08','0.12'})

l = legend('WAR','CAR','Initial','Location','north');
l.AutoUpdate = 'off';
l.PlotChildren = l.PlotChildren([3,2,1]);
l.Location = 'northeast';
l.FontSize = 6.5;
l.Position = [0.2475 0.4348 0 0];
l.ItemTokenSize = [15 5];

%% diatoms
% no resuspension
subplot(2,3,2)

% create y-axis on the left to plot Topt distribution after CA and WA
yyaxis left
ax = gca;
histogram(Topt{2,2},'BinWidth',0.16,'FaceAlpha',0.69,'FaceColor',red2,'Normalization','probability','LineWidth',0.3)
hold on
histogram(Topt{1,2},'BinWidth',0.16,'FaceAlpha',0.5,'FaceColor',blue2,'Normalization','probability','LineWidth',0.3,'EdgeColor',gray2)
histogram(Topt{2,2},'BinWidth',0.16,'FaceAlpha',0.01,'FaceColor',red2,'Normalization','probability','LineWidth',0.3)
ax.YColor = 'k';
ax.XTickLabels = [];
ax.Position = [0.398 0.56 0.23 0.4];
xlim([8 16])
ylim([0 0.09])
ax.YTickLabels = [];
yticks([0 0.03 0.06 0.09])
yticklabels({'0','0.03','0.06','0.09'})
annotation('textbox',[0.392 0.669 0.5 0.3],'String','Diatoms','Color','k','EdgeColor',...
    'none','FontSize',8,'FontWeight','normal')

% create y-axis on the right to plot initial Topt
yyaxis right
ax = gca;
ax.FontSize = 8;
h2 = histogram(12,'FaceColor',gray1,'FaceAlpha',0.7,'Normalization','probability');
ax.YColor = gray1;
h2.BinWidth = 0.16;
h2.LineWidth = 0.3;

%% resuspension
subplot(2,3,5)

% create y-axis on the left to plot Topt distribution after CAR and WAR
yyaxis left
ax = gca;
ax.FontSize = 8;
histogram(Topt{4,2},'BinWidth',0.16,'FaceAlpha',0.69,'FaceColor',red2,'Normalization','probability','LineWidth',0.3)
hold on
histogram(Topt{3,2},'BinWidth',0.16,'FaceAlpha',0.5,'FaceColor',blue2,'Normalization','probability','LineWidth',0.3,'EdgeColor',gray2)
histogram(Topt{4,2},'BinWidth',0.16,'FaceAlpha',0.01,'FaceColor',red2,'Normalization','probability','LineWidth',0.3)
ax.YColor = 'k';
xlabel('Optimum temperature [°C]','FontSize',8)
xlim([8 16])
ylim([0 0.09])
ax.YTickLabels = [];
yticks([0 0.03 0.06 0.09])
yticklabels({'0','0.03','0.06','0.09'})

% create y-axis on the right to plot initial Topt
yyaxis right
ax = gca;
h2 = histogram(12,'FaceColor',gray1,'BinWidth',0.15,'FaceAlpha',0.7,'Normalization','probability');
ax.YColor = gray1;
ax.Position = [0.398 0.1 0.23 0.4];
h2.BinWidth = 0.16;
h2.LineWidth = 0.3;

%% cyanobacteria
% no resuspension
subplot(2,3,3)

% create y-axis on the left to plot Topt distribution after CA and WA
yyaxis left
ax = gca;
ax.FontSize = 8;
histogram(Topt{2,3},'BinWidth',0.24,'FaceAlpha',0.69,'FaceColor',red2,'Normalization','probability','LineWidth',0.3) %0.8
hold on
h1 = histogram(Topt{1,3},'BinWidth',0.24,'FaceAlpha',0.5,'FaceColor',blue2,'Normalization','probability','LineWidth',0.3,'EdgeColor',gray2); %0.63
histogram(Topt{2,3},'BinWidth',0.24,'FaceAlpha',0.01,'FaceColor',red2,'Normalization','probability','LineWidth',0.3)
ax.YColor = 'k';
ylim([0 0.1])
ax.YTickLabels = [];
yticks([0 0.025 0.05 0.075 0.1])
yticklabels({'0','0.025','0.05','0.075','0.1'})

% create y-axis on the right to plot initial Topt
yyaxis right
ax = gca;
h2 = histogram(28.5,'FaceColor',gray1,'BinWidth',0.24,'FaceAlpha',0.7,'Normalization','probability');
ax.YColor = gray1;
ax.XTickLabels = [];
ax.Position = [0.725 0.56 0.23 0.4];
h2.BinWidth = h1.BinWidth;
h2.LineWidth = 0.3;
xlim([22 34])
ylim([0 1])
annotation('textbox',[0.719 0.669 0.5 0.3],'String','Cyanob.','Color','k','EdgeColor',...
    'none','FontSize',8,'FontWeight','normal')

%% resuspension
subplot(2,3,6)

% create y-axis on the left to plot Topt distribution after CAR and WAR
yyaxis left
ax = gca;
ax.FontSize = 8;
h1 = histogram(Topt{4,3},'BinWidth',0.24,'FaceAlpha',0.69,'FaceColor',red2,'Normalization','probability','LineWidth',0.3);
hold on
histogram(Topt{3,3},'BinWidth',0.24,'FaceAlpha',0.5,'FaceColor',blue2,'Normalization','probability','LineWidth',0.3,'EdgeColor',gray2)
histogram(Topt{4,3},'BinWidth',0.24,'FaceAlpha',0.01,'FaceColor',red2,'Normalization','probability','LineWidth',0.3)
ax.YColor = 'k';
ylim([0 0.1])
ax.YTickLabels = [];
yticks([0 0.025 0.05 0.075 0.1])
yticklabels({'0','0.025','0.05','0.075','0.1'})
xlabel('Optimum temperature [°C]','FontSize',8)

% create y-axis on the right to plot initial Topt
yyaxis right
ax = gca;
h2 = histogram(28.5,'FaceColor',gray1,'BinWidth',0.24,'FaceAlpha',0.7,'Normalization','probability');
ax.YColor = gray1;
h2.BinWidth = h1.BinWidth;
h2.LineWidth = 0.3;
ax.Position = [0.725 0.1 0.23 0.4];
xlim([22 34])
ylim([0 1])

%% save figure
pause(n)
fig = figure(2);
fig.Units = 'centimeters';
fig.Position = [0 0 12.7 7.5];
figureName = '../Output_Plots/Fig3.tiff';
exportgraphics(fig,figureName,'Resolution',1200)

%% statistics
%% dinoflagellates
statsDin = cell(3,7);
% C vs. CA
[hDin(1,1,1),pDin(1,1,1),ciDin(1:2,1,1),statsDin{1,1}] = ttest2(C.timing(1,:),CA.timing(1,:));
[hDin(2,1,1),pDin(2,1,1),ciDin(3:4,1,1),statsDin{2,1}] = ttest2(C.amplitude(1,:),CA.amplitude(1,:));
% CA vs. CAR
[hDin(1,2,1),pDin(1,2,1),ciDin(1:2,2,1),statsDin{1,2}] = ttest2(CA.timing(1,:),CAR.timing(1,:));
[hDin(2,2,1),pDin(2,2,1),ciDin(3:4,2,1),statsDin{2,2}] = ttest2(CA.amplitude(1,:),CAR.amplitude(1,:));
[hDin(3,2,1),pDin(3,2,1),ciDin(5:6,2,1),statsDin{3,2}] = ttest2(CA.Topt_stat2(1,:),CAR.Topt_stat2(1,:));

% C vs. W
[hDin(1,1,2),pDin(1,1,2),ciDin(1:2,1,2),statsDin{1,3}] = ttest(C.timing(1,:),W.timing(1,:));
[hDin(2,1,2),pDin(2,1,2),ciDin(3:4,1,2),statsDin{2,3}] = ttest(C.amplitude(1,:),W.amplitude(1,:));
% CA vs. WA
[hDin(1,2,2),pDin(1,2,2),ciDin(1:2,2,2),statsDin{1,4}] = ttest(CA.timing(1,:),WA.timing(1,:));
[hDin(2,2,2),pDin(2,2,2),ciDin(3:4,2,2),statsDin{2,4}] = ttest(CA.amplitude(1,:),WA.amplitude(1,:));
[hDin(3,2,2),pDin(3,2,2),ciDin(5:6,2,2),statsDin{3,4}] = ttest(CA.Topt_stat2(1,:),WA.Topt_stat2(1,:));
% CAR vs. WAR
[hDin(1,3,2),pDin(1,3,2),ciDin(1:2,3,2),statsDin{1,5}] = ttest(CAR.timing(1,:),WAR.timing(1,:));
[hDin(2,3,2),pDin(2,3,2),ciDin(3:4,3,2),statsDin{2,5}] = ttest(CAR.amplitude(1,:),WAR.amplitude(1,:));
[hDin(3,3,2),pDin(3,3,2),ciDin(5:6,3,2),statsDin{3,5}] = ttest(CAR.Topt_stat2(1,:),WAR.Topt_stat2(1,:));

% W vs. WA
[hDin(1,1,3),pDin(1,1,3),ciDin(1:2,1,3),statsDin{1,6}] = ttest2(W.timing(1,:),WA.timing(1,:));
[hDin(2,1,3),pDin(2,1,3),ciDin(3:4,1,3),statsDin{2,6}] = ttest2(W.amplitude(1,:),WA.amplitude(1,:));
% WA vs. WAR
[hDin(1,2,3),pDin(1,2,3),ciDin(1:2,2,3),statsDin{1,7}] = ttest2(WA.timing(1,:),WAR.timing(1,:));
[hDin(2,2,3),pDin(2,2,3),ciDin(3:4,2,3),statsDin{2,7}] = ttest2(WA.amplitude(1,:),WAR.amplitude(1,:));
[hDin(3,2,3),pDin(3,2,3),ciDin(5:6,2,3),statsDin{3,7}] = ttest2(WA.Topt_stat2(1,:),WAR.Topt_stat2(1,:));

%% diatoms
statsDia = cell(5,7);
% C vs. CA
[hDia(1,1,1),pDia(1,1,1),ciDia(1:2,1,1),statsDia{1,1}] = ttest2(C.timing(2,:),CA.timing(2,:));
[hDia(2,1,1),pDia(2,1,1),ciDia(3:4,1,1),statsDia{2,1}] = ttest2(C.timing(3,:),CA.timing(3,:));
[hDia(3,1,1),pDia(3,1,1),ciDia(5:6,1,1),statsDia{3,1}] = ttest2(C.amplitude(2,:),CA.amplitude(2,:));
[hDia(4,1,1),pDia(4,1,1),ciDia(7:8,1,1),statsDia{4,1}] = ttest2(C.amplitude(3,:),CA.amplitude(3,:));
% CA vs. CAR
[hDia(1,2,1),pDia(1,2,1),ciDia(1:2,2,1),statsDia{1,2}] = ttest2(CA.timing(2,:),CAR.timing(2,:));
[hDia(2,2,1),pDia(2,2,1),ciDia(3:4,2,1),statsDia{2,2}] = ttest2(CA.timing(3,:),CAR.timing(3,:));
[hDia(3,2,1),pDia(3,2,1),ciDia(5:6,2,1),statsDia{3,2}] = ttest2(CA.amplitude(2,:),CAR.amplitude(2,:));
[hDia(4,2,1),pDia(4,2,1),ciDia(7:8,2,1),statsDia{4,2}] = ttest2(CA.amplitude(3,:),CAR.amplitude(3,:));
[hDia(5,2,1),pDia(5,2,1),ciDia(9:10,2,1),statsDia{5,2}] = ttest2(CA.Topt_stat2(2,:),CAR.Topt_stat2(2,:));

% C vs. W
[hDia(1,1,2),pDia(1,1,2),ciDia(1:2,1,2),statsDia{1,3}] = ttest(C.timing(2,:),W.timing(2,:));
[hDia(2,1,2),pDia(2,1,2),ciDia(3:4,1,2),statsDia{2,3}] = ttest(C.timing(3,:),W.timing(3,:));
[hDia(3,1,2),pDia(3,1,2),ciDia(5:6,1,2),statsDia{3,3}] = ttest(C.amplitude(2,:),W.amplitude(2,:));
[hDia(4,1,2),pDia(4,1,2),ciDia(7:8,1,2),statsDia{4,3}] = ttest(C.amplitude(3,:),W.amplitude(3,:));
% CA vs. WA
[hDia(1,2,2),pDia(1,2,2),ciDia(1:2,2,2),statsDia{1,4}] = ttest(CA.timing(2,:),WA.timing(2,:));
[hDia(2,2,2),pDia(2,2,2),ciDia(3:4,2,2),statsDia{2,4}] = ttest(CA.timing(3,:),WA.timing(3,:));
[hDia(3,2,2),pDia(3,2,2),ciDia(5:6,2,2),statsDia{3,4}] = ttest(CA.amplitude(2,:),WA.amplitude(2,:));
[hDia(4,2,2),pDia(4,2,2),ciDia(7:8,2,2),statsDia{4,4}] = ttest(CA.amplitude(3,:),WA.amplitude(3,:));
[hDia(5,2,2),pDia(5,2,2),ciDia(9:10,2,2),statsDia{5,4}] = ttest(CA.Topt_stat2(2,:),WA.Topt_stat2(2,:));
% CAR vs. WAR
[hDia(1,3,2),pDia(1,3,2),ciDia(1:2,3,2),statsDia{1,5}] = ttest(CAR.timing(2,:),WAR.timing(2,:));
[hDia(2,3,2),pDia(2,3,2),ciDia(3:4,3,2),statsDia{2,5}] = ttest(CAR.timing(3,:),WAR.timing(3,:));
[hDia(3,3,2),pDia(3,3,2),ciDia(5:6,3,2),statsDia{3,5}] = ttest(CAR.amplitude(2,:),WAR.amplitude(2,:));
[hDia(4,3,2),pDia(4,3,2),ciDia(7:8,3,2),statsDia{4,5}] = ttest(CAR.amplitude(3,:),WAR.amplitude(3,:));
[hDia(5,3,2),pDia(5,3,2),ciDia(9:10,3,2),statsDia{5,5}] = ttest(CAR.Topt_stat2(2,:),WAR.Topt_stat2(2,:));

% W vs. WA
[hDia(1,1,3),pDia(1,1,3),ciDia(1:2,1,3),statsDia{1,6}] = ttest2(W.timing(2,:),WA.timing(2,:));
[hDia(2,1,3),pDia(2,1,3),ciDia(3:4,1,3),statsDia{2,6}] = ttest2(W.timing(3,:),WA.timing(3,:));
[hDia(3,1,3),pDia(3,1,3),ciDia(5:6,1,3),statsDia{3,6}] = ttest2(W.amplitude(2,:),WA.amplitude(2,:));
[hDia(4,1,3),pDia(4,1,3),ciDia(7:8,1,3),statsDia{4,6}] = ttest2(W.amplitude(3,:),WA.amplitude(3,:));
% WA vs. WAR
[hDia(1,2,3),pDia(1,2,3),ciDia(1:2,2,3),statsDia{1,7}] = ttest2(WA.timing(2,:),WAR.timing(2,:));
[hDia(2,2,3),pDia(2,2,3),ciDia(3:4,2,3),statsDia{2,7}] = ttest2(WA.timing(3,:),WAR.timing(3,:));
[hDia(3,2,3),pDia(3,2,3),ciDia(5:6,2,3),statsDia{3,7}] = ttest2(WA.amplitude(2,:),WAR.amplitude(2,:));
[hDia(4,2,3),pDia(4,2,3),ciDia(7:8,2,3),statsDia{4,7}] = ttest2(WA.amplitude(3,:),WAR.amplitude(3,:));
[hDia(5,2,3),pDia(5,2,3),ciDia(9:10,2,3),statsDia{5,7}] = ttest2(WA.Topt_stat2(2,:),WAR.Topt_stat2(2,:));

%% cyanobacteria
% C vs. CA
[hCya(1,1,1),pCya(1,1,1),ciCya(1:2,1,1),statsCya{1,1}] = ttest2(C.timing(4,:),CA.timing(4,:));
[hCya(2,1,1),pCya(2,1,1),ciCya(3:4,1,1),statsCya{2,1}] = ttest2(C.amplitude(4,:),CA.amplitude(4,:));
% CA vs. CAR
[hCya(1,2,1),pCya(1,2,1),ciCya(1:2,2,1),statsCya{1,2}] = ttest2(CA.timing(4,:),CAR.timing(4,:));
[hCya(2,2,1),pCya(2,2,1),ciCya(3:4,2,1),statsCya{2,2}] = ttest2(CA.amplitude(4,:),CAR.amplitude(4,:));
[hCya(3,2,1),pCya(3,2,1),ciCya(5:6,2,1),statsCya{3,2}] = ttest2(CA.Topt_stat2(3,:),CAR.Topt_stat2(3,:));

% C vs. W
[hCya(1,1,2),pCya(1,1,2),ciCya(1:2,1,2),statsCya{1,3}] = ttest(C.timing(4,:),W.timing(4,:));
[hCya(2,1,2),pCya(2,1,2),ciCya(3:4,1,2),statsCya{2,3}] = ttest(C.amplitude(4,:),W.amplitude(4,:));
% CA vs. WA
[hCya(1,2,2),pCya(1,2,2),ciCya(1:2,2,2),statsCya{1,4}] = ttest(CA.timing(4,:),WA.timing(4,:));
[hCya(2,2,2),pCya(2,2,2),ciCya(3:4,2,2),statsCya{2,4}] = ttest(CA.amplitude(4,:),WA.amplitude(4,:));
[hCya(3,2,2),pCya(3,2,2),ciCya(5:6,2,2),statsCya{3,4}] = ttest(CA.Topt_stat2(3,:),WA.Topt_stat2(3,:));
% CAR vs. WAR
[hCya(1,3,2),pCya(1,3,2),ciCya(1:2,3,2),statsCya{1,5}] = ttest(CAR.timing(4,:),WAR.timing(4,:));
[hCya(2,3,2),pCya(2,3,2),ciCya(3:4,3,2),statsCya{2,5}] = ttest(CAR.amplitude(4,:),WAR.amplitude(4,:));
[hCya(3,3,2),pCya(3,3,2),ciCya(5:6,3,2),statsCya{3,5}] = ttest(CAR.Topt_stat2(3,:),WAR.Topt_stat2(3,:));

% W vs. WA
[hCya(1,1,3),pCya(1,1,3),ciCya(1:2,1,3),statsCya{1,6}] = ttest2(W.timing(4,:),WA.timing(4,:));
[hCya(2,1,3),pCya(2,1,3),ciCya(3:4,1,3),statsCya{2,6}] = ttest2(W.amplitude(4,:),WA.amplitude(4,:));
% WA vs. WAR
[hCya(1,2,3),pCya(1,2,3),ciCya(1:2,2,3),statsCya{1,7}] = ttest2(WA.timing(4,:),WAR.timing(4,:));
[hCya(2,2,3),pCya(2,2,3),ciCya(3:4,2,3),statsCya{2,7}] = ttest2(WA.amplitude(4,:),WAR.amplitude(4,:));
[hCya(3,2,3),pCya(3,2,3),ciCya(5:6,2,3),statsCya{3,7}] = ttest2(WA.Topt_stat2(3,:),WAR.Topt_stat2(3,:));
