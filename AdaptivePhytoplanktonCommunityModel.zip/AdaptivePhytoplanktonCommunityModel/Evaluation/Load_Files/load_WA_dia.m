%% load_WA_dia.m
% load WA simulations with only diatoms and save variables required for evaluation

clearvars
close all

%% load files
numFiles = 7;
% WA
WA(1) = load('../Output_Files/WA_dia_1_1200.mat');
WA(2) = load('../Output_Files/WA_dia_2_1200.mat');
WA(3) = load('../Output_Files/WA_dia_3_1200.mat');
WA(4) = load('../Output_Files/WA_dia_4_1200.mat');
WA(5) = load('../Output_Files/WA_dia_5_1200.mat');
WA(6) = load('../Output_Files/WA_dia_6_1200.mat');
WA(7) = load('../Output_Files/WA_dia_7_1200.mat');

%% AVERAGE BIOMASS
timing = zeros(3,numFiles);
amplitude = zeros(4,numFiles);
stats = zeros(4,6);

%% diatoms
P = zeros(8640,numFiles);
P2 = zeros(100*8640,numFiles);
for iFile = 1:numFiles
    P(:,iFile) = WA(iFile).P2sum(end-360*24+1:end,1);
    P2(:,iFile) = WA(iFile).P2sum(2:end,1);
    [amplitude(2,iFile), timing(2,iFile)] = max(WA(iFile).P2sum(end-360*24+1:end-360*24+240*24,1));
    [amplitude(3,iFile), timing(3,iFile)] = max(WA(iFile).P2sum(end-360*24+240*24+1:end,1));
end
WA_P(:,2) = mean(P,2);
P_all(:,2) = mean(P2,2);
timing(3,:) = timing(3,:) + 240*24;

%% EVOLUTION IN TOPT
Topt2 = WA(1).Topt2;

% merge Topt distributions from the last simulation year
Topt = cell(1,3);
Topt_stat = cell(3,numFiles);

for iFile = 1:numFiles
    for iSpec = 2:2
        for iMonth = 1:12
            Topt{1,iSpec} = [Topt{1,iSpec}; WA(iFile).Topt_total{iMonth,iSpec,100}];
            Topt_stat{iSpec,iFile} = [Topt_stat{iSpec,iFile}; WA(iFile).Topt_total{iMonth,iSpec,100}];
        end
    end
end

Topt_stat2 = zeros(3,numFiles);
for iFile = 1:numFiles
    for iSpec = 2:2
        Topt_stat2(iSpec,iFile) = mean(Topt_stat{iSpec,iFile});
    end
end

%% seasonality
mTopt = zeros(864000,2,numFiles);
for iFile = 1:numFiles
    mTopt(:,:,iFile) = WA(iFile).meanTrait(2:end,1:2,1);
end
mTopt = mean(mTopt,3);

yrTopt = zeros(8640,2,100);
for iYear = 1:100
    for it = 1:8640
        yrTopt(it,:,iYear) = mTopt(it+((iYear-1)*8640),:);
    end
end
yrmTopt = yrTopt(:,:,75:100);
yrmTopt = mean(yrmTopt,3);

%% evolution over the season
Topt_seasonal = cell(100*12,2);
for iFile = 1:numFiles
    for iSpec = 1:2
        for iYear = 1:100
            for iMonth = 1:12
                Topt_seasonal{(iYear-1)*12+iMonth,iSpec} = [Topt_seasonal{(iYear-1)*12+iMonth,iSpec};WA(iFile).Topt_total{iMonth,iSpec,iYear}];
            end
        end
    end
end

%% evolution over 100 years
Topt_ds = {};
for iFile = 1:numFiles
    Topt_ds = [Topt_ds; WA(iFile).Topt_total];
end

Topt_annual = cell(100,2);
for iSpec = 1:2
    for iYear = 1:100
        for iMonth = 1:numFiles*12
            Topt_annual{iYear,iSpec} = [Topt_annual{iYear,iSpec};Topt_ds{iMonth,iSpec,iYear}];
        end
    end
end

%% CELL SIZE
meanTrait = zeros(864000,2,numFiles);
for iFile = 1:numFiles
    meanTrait(:,:,iFile) = WA(iFile).meanTrait(2:end,1:2,2);
end
meanTrait = mean(meanTrait,3);

%% ECOLOGICAL CHANGES
% annual mean biomass
Nyears = WA(1).Nyears;
Pmean_tmp = zeros(Nyears,4,numFiles);
spy = 24*360-2;

for iFile = 1:numFiles
    for iSpecies = 1:4
        count = 2;
        for iYear = 1:Nyears
            Pmean_tmp(iYear,iSpecies,iFile) = mean(WA(iFile).P(count:count+spy,iSpecies));
            count = count + spy + 1;
        end
    end
end

Pmean = zeros(100,3,numFiles);
for iFile = 1:numFiles
    Pmean(:,:,iFile) = Pmean_tmp(:,1:3,iFile);
end
Pmean = mean(Pmean,3);

% bloom timing
Pidx = zeros(100*360*24,3,numFiles);
for iFile = 1:numFiles
    Pidx(:,2,iFile) = WA(iFile).P2sum(1:end-1,1);
end
Pidx = mean(Pidx,3);

time = 1:100;
idx = zeros(length(time),4);
for iSpec = 2:2
    for iTime = 1:length(time)
        [~,idx(iTime,iSpec)] = max(Pidx(360*24*iTime-360*24+1:360*24*iTime-360*24+270*24,iSpec));
        if iSpec == 2
            [~,idx(iTime,iSpec+2)] = max(Pidx(360*24*iTime-360*24+271*24:360*24*iTime,iSpec));
        end
    end
end
idx(:,4) = idx(:,4) + 271*24;
idx = idx/24;

%% environmental forcing
temp = WA(1).temp;
IL = WA(1).IL;
N = WA(1).N;

%% statistics
% diatoms spring
stats(2,1) = mean(timing(2,:))/24;
stats(2,2) = std(timing(2,:))/24;
stats(2,3) = mean(amplitude(2,:));
stats(2,4) = std(amplitude(2,:));
stats(2,5) = mean(Topt_stat2(2,:));
stats(2,6) = std(Topt_stat2(2,:));
% diatoms autumn
stats(3,1) = mean(timing(3,:))/24;
stats(3,2) = std(timing(3,:))/24;
stats(3,3) = mean(amplitude(3,:));
stats(3,4) = std(amplitude(3,:));
stats(3,5) = mean(Topt_stat2(2,:));
stats(3,6) = std(Topt_stat2(2,:));

%% save variable
save("../Output_Files/WA_dia_vars.mat","WA_P","P_all","Topt","yrmTopt","mTopt","meanTrait",...
    "Topt_annual","Pmean","idx","temp","IL","N","Topt2","stats","timing","amplitude","Topt_stat2",...
    "Topt_seasonal");
