%% load_C.m
% load C simulations and save variables required for evaluation

clearvars
close all

%% load files
numFiles = 7;
% C
C(1) = load('../Output_Files/C1_1200.mat');
C(2) = load('../Output_Files/C2_1200.mat');
C(3) = load('../Output_Files/C3_1200.mat');
C(4) = load('../Output_Files/C4_1200.mat');
C(5) = load('../Output_Files/C5_1200.mat');
C(6) = load('../Output_Files/C6_1200.mat');
C(7) = load('../Output_Files/C7_1200.mat');

%% AVERAGE BIOMASS
timing = zeros(3,numFiles);
amplitude = zeros(4,numFiles);
stats = zeros(4,4);

%% dinoflagellates
P = zeros(8640,numFiles);
for iFile = 1:numFiles
    P(:,iFile) = C(iFile).P1sum(end-360*24+1:end,1);
    [amplitude(1,iFile), timing(1,iFile)] = max(C(iFile).P1sum(end-360*24+1:end,1));
end
C_P(:,1) = mean(P,2);

%% diatoms
P = zeros(8640,numFiles);
for iFile = 1:numFiles
    P(:,iFile) = C(iFile).P2sum(end-360*24+1:end,1);
    [amplitude(2,iFile), timing(2,iFile)] = max(C(iFile).P2sum(end-360*24+1:end-360*24+240*24,1));
    [amplitude(3,iFile), timing(3,iFile)] = max(C(iFile).P2sum(end-360*24+240*24+1:end,1));
end
C_P(:,2) = mean(P,2);
timing(3,:) = timing(3,:) + 240*24;

%% cyanobacteria
P = zeros(8640,numFiles);
for iFile = 1:numFiles
    P(:,iFile) = C(iFile).P3sum(end-360*24+1:end,1) + C(iFile).P3sum(end-360*24+1:end,2);
    [amplitude(4,iFile), timing(4,iFile)] = max(C(iFile).P3sum(end-360*24+1:end,1) + C(iFile).P3sum(end-360*24+1:end,2));
end
C_P(:,3) = mean(P,2);

%% statistics
% dinoflagellates
stats(1,1) = mean(timing(1,:))/24;
stats(1,2) = std(timing(1,:))/24;
stats(1,3) = mean(amplitude(1,:));
stats(1,4) = std(amplitude(1,:));
% diatoms spring
stats(2,1) = mean(timing(2,:))/24;
stats(2,2) = std(timing(2,:))/24;
stats(2,3) = mean(amplitude(2,:));
stats(2,4) = std(amplitude(2,:));
% diatoms autumn
stats(3,1) = mean(timing(3,:))/24;
stats(3,2) = std(timing(3,:))/24;
stats(3,3) = mean(amplitude(3,:));
stats(3,4) = std(amplitude(3,:));
% cyanobacteria
stats(4,1) = mean(timing(4,:))/24;
stats(4,2) = std(timing(4,:))/24;
stats(4,3) = mean(amplitude(4,:));
stats(4,4) = std(amplitude(4,:));

%% save variables
save("../Output_Files/C_vars.mat","C_P","stats","amplitude","timing");
