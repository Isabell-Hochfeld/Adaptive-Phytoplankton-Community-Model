%% load_WAR.m
% load WAR simulations and save variables required for evaluation

clearvars
close all

%% load files
numFiles = 7;
% WAR
WAR(1) = load('../Output_Files/WAR1_1200.mat');
WAR(2) = load('../Output_Files/WAR2_1200.mat');
WAR(3) = load('../Output_Files/WAR3_1200.mat');
WAR(4) = load('../Output_Files/WAR4_1200.mat');
WAR(5) = load('../Output_Files/WAR5_1200.mat');
WAR(6) = load('../Output_Files/WAR6_1200.mat');
WAR(7) = load('../Output_Files/WAR7_1200.mat');

%% AVERAGE BIOMASS
timing = zeros(3,numFiles);
amplitude = zeros(4,numFiles);
stats = zeros(4,6);

%% dinoflagellates
P = zeros(8640,numFiles);
for iFile = 1:numFiles
    P(:,iFile) = WAR(iFile).P1sum(end-360*24+1:end,1);
    [amplitude(1,iFile), timing(1,iFile)] = max(WAR(iFile).P1sum(end-360*24+1:end,1));
end
WAR_P(:,1) = mean(P,2);

%% diatoms
P = zeros(8640,numFiles);
for iFile = 1:numFiles
    P(:,iFile) = WAR(iFile).P2sum(end-360*24+1:end,1);
    [amplitude(2,iFile), timing(2,iFile)] = max(WAR(iFile).P2sum(end-360*24+1:end-360*24+240*24,1));
    [amplitude(3,iFile), timing(3,iFile)] = max(WAR(iFile).P2sum(end-360*24+240*24+1:end,1));
end
WAR_P(:,2) = mean(P,2);
timing(3,:) = timing(3,:) + 240*24;

%% cyanobacteria
P = zeros(8640,numFiles);
for iFile = 1:numFiles
    P(:,iFile) = WAR(iFile).P3sum(end-360*24+1:end,1) + WAR(iFile).P3sum(end-360*24+1:end,2);
    [amplitude(4,iFile), timing(4,iFile)] = max(WAR(iFile).P3sum(end-360*24+1:end,1) + WAR(iFile).P3sum(end-360*24+1:end,2));
end
WAR_P(:,3) = mean(P,2);

%% EVOLUTION IN TOPT
% merge Topt distributions from the last simulation year
Topt = cell(1,3);
Topt_stat = cell(3,numFiles);

for iFile = 1:numFiles
    for iSpec = 1:3
        for iMonth = 1:12
            Topt{1,iSpec} = [Topt{1,iSpec}; WAR(iFile).Topt_total{iMonth,iSpec,100}];
            Topt_stat{iSpec,iFile} = [Topt_stat{iSpec,iFile}; WAR(iFile).Topt_total{iMonth,iSpec,100}];
        end
    end
end

Topt_stat2 = zeros(3,numFiles);
for iFile = 1:numFiles
    for iSpec = 1:3
        Topt_stat2(iSpec,iFile) = mean(Topt_stat{iSpec,iFile});
    end
end

mTopt = zeros(864000,3,numFiles);
for iFile = 1:numFiles
    mTopt(:,:,iFile) = WAR(iFile).meanTrait(2:end,1:3,1);
end
mTopt = mean(mTopt,3);

%% evolution over 100 years
Topt_ds = {};
for iFile = 1:numFiles
    Topt_ds = [Topt_ds; WAR(iFile).Topt_total];
end

Topt_annual = cell(100,3);
for iSpec = 1:3
    for iYear = 1:100
        for iMonth = 1:numFiles*12
            Topt_annual{iYear,iSpec} = [Topt_annual{iYear,iSpec};Topt_ds{iMonth,iSpec,iYear}];
        end
    end
end

%% statistics
% dinoflagellates
stats(1,1) = mean(timing(1,:))/24;
stats(1,2) = std(timing(1,:))/24;
stats(1,3) = mean(amplitude(1,:));
stats(1,4) = std(amplitude(1,:));
stats(1,5) = mean(Topt_stat2(1,:));
stats(1,6) = std(Topt_stat2(1,:));
% diatoms spring
stats(2,1) = mean(timing(2,:))/24;
stats(2,2) = std(timing(2,:))/24;
stats(2,3) = mean(amplitude(2,:));
stats(2,4) = std(amplitude(2,:));
stats(2,5) = mean(Topt_stat2(2,:));
stats(2,6) = std(Topt_stat2(2,:));
% diatoms autumn
stats(3,1) = mean(timing(3,:))/24;
stats(3,2) = std(timing(3,:))/24;
stats(3,3) = mean(amplitude(3,:));
stats(3,4) = std(amplitude(3,:));
stats(3,5) = mean(Topt_stat2(2,:));
stats(3,6) = std(Topt_stat2(2,:));
% cyanobacteria
stats(4,1) = mean(timing(4,:))/24;
stats(4,2) = std(timing(4,:))/24;
stats(4,3) = mean(amplitude(4,:));
stats(4,4) = std(amplitude(4,:));
stats(4,5) = mean(Topt_stat2(3,:));
stats(4,6) = std(Topt_stat2(3,:));

%% save variable
save("../Output_Files/WAR_vars.mat","WAR_P","Topt","stats","timing",...
    "amplitude","Topt_stat2","mTopt","Topt_annual");
