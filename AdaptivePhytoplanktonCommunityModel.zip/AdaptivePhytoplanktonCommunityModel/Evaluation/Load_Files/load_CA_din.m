%% load_CA_din.m
% load CA simulations with only dinoflagellates and save variables required for evaluation

clearvars
close all

%% load files
numFiles = 7;
% CA
CA(1) = load('../Output_Files/CA_din_1_1200.mat');
CA(2) = load('../Output_Files/CA_din_2_1200.mat');
CA(3) = load('../Output_Files/CA_din_3_1200.mat');
CA(4) = load('../Output_Files/CA_din_4_1200.mat');
CA(5) = load('../Output_Files/CA_din_5_1200.mat');
CA(6) = load('../Output_Files/CA_din_6_1200.mat');
CA(7) = load('../Output_Files/CA_din_7_1200.mat');

%% AVERAGE BIOMASS
timing = zeros(1,numFiles);
amplitude = zeros(1,numFiles);
stats = zeros(1,6);

%% dinoflagellates
P = zeros(8640,numFiles);
for iFile = 1:numFiles
    P(:,iFile) = CA(iFile).P1sum(end-360*24+1:end,1);
    [amplitude(1,iFile), timing(1,iFile)] = max(CA(iFile).P1sum(end-360*24+1:end,1));
end
CA_P(:,1) = mean(P,2);

%% EVOLUTION IN TOPT
Topt1 = CA(1).Topt1;

% merge Topt distributions from the last simulation year
Topt = cell(1,1);
Topt_stat = cell(1,numFiles);

for iFile = 1:numFiles
    for iSpec = 1:1
        for iMonth = 1:12
            Topt{1,iSpec} = [Topt{1,iSpec}; CA(iFile).Topt_total{iMonth,iSpec,100}];
            Topt_stat{iSpec,iFile} = [Topt_stat{iSpec,iFile}; CA(iFile).Topt_total{iMonth,iSpec,100}];
        end
    end
end

Topt_stat2 = zeros(1,numFiles);
for iFile = 1:numFiles
    for iSpec = 1:1
        Topt_stat2(iSpec,iFile) = mean(Topt_stat{iSpec,iFile});
    end
end

%% seasonality
mTopt = zeros(864000,1,numFiles);
for iFile = 1:numFiles
    mTopt(:,:,iFile) = CA(iFile).meanTrait(2:end,1,1);
end
mTopt = mean(mTopt,3);

yrTopt = zeros(8640,3,100);
for iYear = 1:100
    for it = 1:8640
        yrTopt(it,:,iYear) = mTopt(it+((iYear-1)*8640),:);
    end
end
yrmTopt = yrTopt(:,:,75:100);
yrmTopt = mean(yrmTopt,3);

%% evolution over the season
Topt_seasonal = cell(100*12,1);
for iFile = 1:numFiles
    for iSpec = 1:1
        for iYear = 1:100
            for iMonth = 1:12
                Topt_seasonal{(iYear-1)*12+iMonth,iSpec} = [Topt_seasonal{(iYear-1)*12+iMonth,iSpec};CA(iFile).Topt_total{iMonth,iSpec,iYear}];
            end
        end
    end
end

%% evolution over 100 years
Topt_ds = {};
for iFile = 1:numFiles
    Topt_ds = [Topt_ds; CA(iFile).Topt_total];
end

Topt_annual = cell(100,1);
for iSpec = 1:1
    for iYear = 1:100
        for iMonth = 1:numFiles*12
            Topt_annual{iYear,iSpec} = [Topt_annual{iYear,iSpec};Topt_ds{iMonth,iSpec,iYear}];
        end
    end
end

%% CELL SIZE
meanTrait = zeros(864000,1,numFiles);
for iFile = 1:numFiles
    meanTrait(:,:,iFile) = CA(iFile).meanTrait(2:end,1,2);
end
meanTrait = mean(meanTrait,3);

%% ECOLOGICAL CHANGES
% annual mean biomass
Nyears = CA(1).Nyears;
Pmean_tmp = zeros(Nyears,4,numFiles);
spy = 24*360-2;

for iFile = 1:numFiles
    for iSpecies = 1:1
        count = 2;
        for iYear = 1:Nyears
            Pmean_tmp(iYear,iSpecies,iFile) = mean(CA(iFile).P(count:count+spy,iSpecies));
            count = count + spy + 1;
        end
    end
end

Pmean = zeros(100,1,numFiles);
for iFile = 1:numFiles
    Pmean(:,:,iFile) = Pmean_tmp(:,1,iFile);
end
Pmean = mean(Pmean,3);

% bloom timing
Pidx = zeros(100*360*24,3,numFiles);
for iFile = 1:numFiles
    Pidx(:,1,iFile) = CA(iFile).P1sum(1:end-1,1);
end
Pidx = mean(Pidx,3);

time = 1:100;
idx = zeros(length(time),4);
for iSpec = 1:1
    for iTime = 1:length(time)
        [~,idx(iTime,iSpec)] = max(Pidx(360*24*iTime-360*24+1:360*24*iTime-360*24+270*24,iSpec));
        if iSpec == 2
            [~,idx(iTime,iSpec+2)] = max(Pidx(360*24*iTime-360*24+271*24:360*24*iTime,iSpec));
        end
    end
end
idx(:,4) = idx(:,4) + 271*24;
idx = idx/24;

%% environmental forcing
temp = CA(1).temp;
IL = CA(1).IL;
N = CA(1).N;

%% statistics
% dinoflagellates
stats(1,1) = mean(timing(1,:))/24;
stats(1,2) = std(timing(1,:))/24;
stats(1,3) = mean(amplitude(1,:));
stats(1,4) = std(amplitude(1,:));
stats(1,5) = mean(Topt_stat2(1,:));
stats(1,6) = std(Topt_stat2(1,:));

%% save variable
save("../Output_Files/CA_din_vars.mat","CA_P","Topt","yrmTopt","mTopt","meanTrait",...
    "Topt_annual","Pmean","idx","temp","IL","N",...
    "Topt1","stats","timing","amplitude","Topt_stat2",...
    "Topt_seasonal");
