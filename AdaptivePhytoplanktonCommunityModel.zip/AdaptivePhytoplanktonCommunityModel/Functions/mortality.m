function[P,Psed,mP,mC,gZ] = mortality(P,Psed,mProb,bProb,gProb,Q,it)

% function to calculate loss though grazing, mortality, and burial (resting cells only)

% input:
% - P: phytoplankton array
% - Psed: array containing buried phytoplankton resting cells
% - mProb: mortality probability
% - bProb: burial probability
% - gProb: grazing probability
% - Q: internal nitrogen quota [mmol N]
% - it: iteration
% output:
% - P: phytoplankton array
% - Psed: array containing buried phytoplankton resting cells
% - mP: nitrogen content of dead phytoplankton cells [mmol N]
% - mC: carbon content of dead phytoplankton cells [mmol C]
% - gZ: nitrogen content of grazed phytoplankton cells [mmol N]

V = Mass2Volume(P(:,1));          % cell volume [mu m^3]
Qc = 18.0*10^(-12)*V.^0.94;       % carbon content per cell [mmol C] (Menden-Deuer and Lessard, 2000)

mP = 0;
mC = 0;
gZ = 0;

for iCell = 1:length(P(:,1))
    % mortality
    if rand < mProb
        mP = mP + P(iCell,1) + Q(iCell,1);
        mC = mC + Qc(iCell);
        P(iCell,1) = NaN;
    % grazing
    elseif rand < gProb
        gZ = gZ + P(iCell,1) + Q(iCell,1);
        P(iCell,1) = NaN;
    % burial
    elseif rand < bProb
        Psed(end+1,1:end-1) = P(iCell,:);
        Psed(end,end) = it;
        P(iCell,1) = NaN;
    end
end
P(isnan(P(:,1)),:) = [];              % delete all cells lost during the time step
