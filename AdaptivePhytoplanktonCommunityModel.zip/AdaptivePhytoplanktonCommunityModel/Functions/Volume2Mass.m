function[b] = Volume2Mass(V)

% function to convert cell volume into biomass

% input:
% - V: cell volume [mu m^3]
% output:
% - b: cell biomass [mmol N]

% cellular carbon content [mol C] (Menten-Deuer and Lessard, 2000)
b_C = 10^(-3)*18.0*10^(-12)*V.^(0.94);  
% cellular nitrogen content [mmol N] (Redfield, 1985)
b = 10^3*16*b_C/106;
