function[muMax,rho,kN] = maxRates3(b,Q,N)

% function to calculate the nitrogen-limited growth rate, nitrogen uptake,
% and the half saturation constant for nitrogen based on allometric 
% relations and a variable-internal-stores (VIS) model (Grover, 1991)

% input:
% - b: cell biomass [mmol N]
% - Q: internal nitrogen quota [mmol N]
% - N: nitrogen concentration [mmol N m^-3]
% output:
% - muMax: nitrogen-limited growth rate [h^-1]
% - rho: nitrogen uptake [h^-1]
% - kN: half saturation constant for nitrogen [mmol N m^-3]

dt = 60*60;                                     % time step [s]
secondsPerDay = dt*24;                          % seconds per day
V = Mass2Volume(b);                             % cell volume [mu m^3]

% derive parameters for VIS model from allometric relations
rhoMax = 0.024*V.^(1.10);                       % maximum nutrient uptake rate [pg N cell^-1 day^-1] (Ward et al., 2017)
Qmin = 0.032*V.^(0.76);                         % minimum cell quota [pg N cell^-1] (Ward et al., 2017)
Qmax = 10^(-1.26)*V.^0.93;                      % maximum cell quota [pg N cell^-1] (Maranon et al, 2013)
muInf = 4.7*V.^(-0.26);                         % growth rate for infinite cell quota [d^-1] (Ward et al., 2017)

% convert parameters to required units
rhoMax = dt*10^(-9)*0.0714*rhoMax/secondsPerDay;% maximum nutrient uptake rate [mmol N cell^-1 h^-1]
Qmin = 10^(-9)*0.0714*Qmin;                     % minimum cell quota [mmol N cell^-1]
Qmax = 10^(-9)*0.0714*Qmax;                     % maximum cell quota [mmol N cell^-1]
muInf = dt*muInf/secondsPerDay;                 % growth rate for infinite cell quota [h^-1]

% calculate nitrogen-limited growth rate
muMax = muInf.*(1-Qmin./Q);                     % nurtient-limited growth rate [h^-1] (Droop, 1973);
muMax(Q <= Qmin) = 0;                           % no growth for cell quotas lower than Qmin (Droop, 1973)

% calculate lower and upper bounds of rhoMax
rho_l = muInf.*(Qmax-Qmin);                     % lower bound of rhoMax [mmol N cell^-1 h^-1], based on Grover (1991)
rho_m = rhoMax;                                 % upper bound of rhoMax [mmol N cell^-1 h^-1], based on Gotham & Rhee (1981)

% caclulate Q-dependent rhoMax
rhoMax2 = rho_m - (rho_m-rho_l).*((Q-Qmin)./(Qmax-Qmin)); % (Grover, 1991) [mmol N cell^-1 h^-1]

% calculate nitrogen uptake during current time step
kN = 0.17*V.^0.27;                              % half saturation constant for nitrogen [mmol N m^-3] (Litchman et al., 2007)
rho = rhoMax2.*N./(kN+N);                       % nutrient uptake [mmol N cell^-1 h^-1] (Grover, 1991)
rho(Q >= Qmax) = 0;                             % no nutrient uptake when Qmax is reached (Droop, 1973)