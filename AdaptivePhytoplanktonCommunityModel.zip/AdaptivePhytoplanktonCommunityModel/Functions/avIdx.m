function[oldest] = avIdx(oldest,avTime)

% function to calculate the index of the oldest array element

% input:
% - oldest: index for current time step
% - avTime: length of array
% output:
% - oldest: index for next time step

if oldest == avTime
    % if current index is the last element, go back to the first element 
    % in the next time step
    oldest = 1;
else
    % else, go one element forward
    oldest = oldest + 1;
end