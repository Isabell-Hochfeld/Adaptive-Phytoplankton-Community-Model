function[fig] = CellSizePlot3(figNum,tDays,dayPlot,temp,y1,y2,y3)

% function to plot reference cell biomass during the seasonal cycle

% input:
% - figNum: figure number
% - tDays: time array to plot [d]
% - dayPlot: first day of period to plot
% - temp: environmental temperature [°C]
% - y1: cell biomass array phytoplankton 1
% - y2: cell biomass array phytoplankton 2
% - y3: cell biomass array phytoplankton 3
% output:
% - fig: figure

default1 = [0 0.4470 0.7410];

fig = figure(figNum);
set(fig,'defaultAxesColorOrder',[default1; [0 0 0]]);

%% dinoflagellates
ax = axes('Position',[0.1 0.69 0.8 0.275]);
ax.YAxis.Color = [0 0 0];

yyaxis right
plot(tDays,temp,'LineWidth',1.5)
hold on

yyaxis left
plot(tDays,y1,'LineWidth',1.5)
l = legend('Din_{veg}','Location','northeast');
l.FontSize = 10;
        
xlim([dayPlot dayPlot+360])
xticks([dayPlot+15 dayPlot+45 dayPlot+75 dayPlot+105 dayPlot+135 ...
    dayPlot+165 dayPlot+195 dayPlot+225 dayPlot+255 dayPlot+285 dayPlot+315 dayPlot+345])
xticklabels({'','','','','','','','','','','',''})


%% diatoms
ax = axes('Position',[0.1 0.38 0.8 0.275]);
ax.YAxis.Color = [0 0 0];

yyaxis right
plot(tDays,temp,'LineWidth',1.5)
ylabel('Environmental temperature [°C]','FontSize',12)
hold on

yyaxis left
plot(tDays,y2,'LineWidth',1.5)
l = legend('Dia_{veg}','Location','northwest');
l.FontSize = 10;
ylabel('Ref. cell biomass [mmol N]','FontSize',12)
        
xlim([dayPlot dayPlot+360])
xticks([dayPlot+15 dayPlot+45 dayPlot+75 dayPlot+105 dayPlot+135 ...
    dayPlot+165 dayPlot+195 dayPlot+225 dayPlot+255 dayPlot+285 dayPlot+315 dayPlot+345])
xticklabels({'','','','','','','','','','','',''})

%% cyanobacteria
ax = axes('Position',[0.1 0.07 0.8 0.275]);
ax.YAxis.Color = [0 0 0];

yyaxis right
plot(tDays,temp,'LineWidth',1.5)
hold on

yyaxis left
plot(tDays,y3(:,1),'LineWidth',1.5)
hold on
plot(tDays,y3(:,2),'--','LineWidth',1.5)
l = legend('Cya_{veg}','Cya_{het}','Location','northeast');
l.FontSize = 10;
        
xlim([dayPlot dayPlot+360])
xticks([dayPlot+15 dayPlot+45 dayPlot+75 dayPlot+105 dayPlot+135 ...
    dayPlot+165 dayPlot+195 dayPlot+225 dayPlot+255 dayPlot+285 dayPlot+315 dayPlot+345])
xticklabels({'J','F','M','A','M','J','J','A','S','O','N','D'})
