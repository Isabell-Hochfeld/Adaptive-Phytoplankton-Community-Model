function[limT] = limTDia(P21,P22,T,theta1,theta2,stage,mutation,Topt2)

% function to calculate temperature limitation of diatoms following Hense &
% Beckann (2015)

% input:
% - P21: vegetative cells (array)
% - P22: resting spores (array)
% - T: temperature [°C]
% - theta1: temperature scale below optimum [°C]
% - theta2: temperature scale above aoptimum [°C]
% - stage: life cycle stage (1: growing stage, 2: resting stage)
% - mutation: array describing which traits are flexible
% - Topt2:  initial optimum temperature [°C]
% oputput:
% - limT: temperature limitation for each cell [-]
 
NP21 = length(P21(:,1));
if stage == 1
    % vegetative cells
    if mutation(1) ~= 0
        Topt = P21(:,2);
    else
        Topt = ones(NP21,1)*Topt2;
    end
    limT = zeros(NP21,1);
    for iCell = 1:NP21
        if T <= Topt(iCell)
            limT(iCell) = exp(-(abs(T-Topt(iCell))/theta1)^2);
        else
            limT(iCell) = exp(-(abs(T-Topt(iCell))/theta2)^3);
        end
    end
else
    % resting spores
    if mutation(1) ~= 0
        Topt = mean(P22(:,2));
    else
        Topt = Topt2;
    end
    if T <= Topt
        limT = exp(-(abs(T-Topt)/theta1)^2);
    else
        limT = exp(-(abs(T-Topt)/theta2)^3);
    end
end