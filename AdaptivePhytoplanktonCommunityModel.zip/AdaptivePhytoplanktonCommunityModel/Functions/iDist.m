function[distOut] = iDist(distIn,meanTrait,sigmaTrait,N)

% function to calculate initial trait distribution

% input:
% - distIn: distribution type
% - meanTrait: mean trait value
% - sigmaTrait: standard deviation
% - N: number of agents
% output:
% - distOut: initial trait distribution

% preallocate output distribution
distOut = zeros(N,1);

% calculate output distribution
if distIn == 1
    % ALL CELLS HAVE THE SAME TRAIT VALUE
    distOut(:,1) = meanTrait;
elseif distIn == 2
    % UNIFORM DISTRIBUTION
    distOut(:,1) = linspace(meanTrait-sigmaTrait,meanTrait+sigmaTrait,N);  
elseif distIn == 3
    % NORMAL DISTRIBUTION
    distOut(:,1) = normrnd(meanTrait,sigmaTrait,[1,N]);
end

