function[P] = CellDivision(P,b0,mutation,mutPb,sigma,idxSize,b15,T)

% function to simulate cell division including mutation and phenotypic
% plasticity

% input:
% - P: phytoplankton array
% - b0: reference cell biomass [mmol N]
% - mutation: array describing which traits are flexible
% - mutPb: mutation probability per division
% - sigma: standard deviation of mutations
% - idxSize: index in P where reference cell biomass is saved
% - b15: biomass at 15°C [mmol N]
% - T: temperature [°C]
% output:
% - P: phytoplankton array

numTraits = length(mutation);

for iCell = 1:length(P(:,1))
    % division if cell is >= double reference biomass
    if P(iCell,1) >= 2*b0(iCell)
        % division of biomass
        P(iCell,1) = 0.5*P(iCell,1);
        % dilution of internal nitrogen quota
        if mutation(2) ~= 0
            P(iCell,idxSize+1) = 0.5*P(iCell,idxSize+1);
        end
        % transition of biomass and traits to daughter cell
        P(end+1,:) = P(iCell,:);
        % mutation and phenotypic plasticity
        for iTrait = 1:numTraits
            % mutation
            if mutation(iTrait) == 1
                if rand < mutPb                
                    % trait of parent cell
                    mu = P(iCell,iTrait+1);      
                    % change trait value of daughter cell
                    P(iCell,iTrait+1) = normrnd(mu,sigma); 
                end
            end
            % phenotypic plasticity
            if mutation(iTrait) == 2
                P(iCell,idxSize) = b15 - 0.025*b15*(T-15);
            end
        end
    end  
end