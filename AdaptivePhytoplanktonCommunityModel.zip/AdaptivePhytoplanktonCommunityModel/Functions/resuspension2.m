function[P,Psed] = resuspension2(P,Psed,rspProb,expProb,it,tScale)

% function to simulate resuspension from the sediment to the actively
% growing population

% input:
% - P: array of actively growing population
% - Psed: array of resting cells in the sediment
% - rspProb: resuspension probability
% - expProb: exponential decrase in resuspension probability? 1 = yes
% - it: iteration
% - tScae: time scale of decrease in resuspension probability [yr]
% output:
% - P: array of actively growing population
% - Psed: array of resting cells in the sediment

for iCell = 1:length(Psed(:,1))
    deltaT = (it - Psed(iCell,end))/(tScale*360*24);
    if expProb == 1
        % exponential decrease
        rProb = rspProb*exp(-deltaT);
    else
        % linear decrease
        rProb = rspProb - deltaT*(rspProb/2000);
    end
    if rand < rProb
        P(end+1,:) = Psed(iCell,1:end-1);
        Psed(iCell,1) = NaN;
    end
end

Psed(isnan(Psed(:,1)),:) = []; % delete all cells resuspended during the time step
