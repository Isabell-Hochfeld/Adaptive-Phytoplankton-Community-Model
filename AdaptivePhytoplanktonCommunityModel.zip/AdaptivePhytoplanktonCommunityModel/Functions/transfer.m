function[P1,P2] = transfer(P1,P2,transProb)

% function to calculate transfer from life cycle stage P1 to stage P2

% input:
% - P1: decresing life cycle stage
% - P2: growing life cycle stage
% - transProb: transition probability
% output:
% - P1: decresing life cycle stage
% - P2: growing life cycle stage

for iCell = 1:length(P1(:,1))
    if rand < transProb
        P2(end+1,:) = P1(iCell,:);
        P1(iCell,1) = NaN;
    end    
end

P1(isnan(P1(:,1)),:) = [];