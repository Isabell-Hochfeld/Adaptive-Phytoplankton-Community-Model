function[gPb] = grazing(dt,pref,gmax,Z,kP,P,type)

% function to calculate grazing probability

% input:
% - dt: time step [s]
% - pref: grazing preference (0<=pref<=1)
% - gmax: maximum grazing rate [h^-1]
% - Z: zooplankton concentration [mmol N m^-3]
% - kP: half saturation constant for phytoplankton [mmol N m^-3]
% - P: phytoplankton concentration [mmol N m^-3]
% - type: Holling-type grazing function (I-IV)
% output:
% - gPb: grazing probability for current time step

% Holling type I response (rectlinear)
if type == 1
    if P < kP
        gPb = dt*pref*Z*gmax*P/kP;
    else
        gPb = dt*pref*Z*gmax;
    end
 
% Holling type II response (hyperbolic)
elseif type == 2
    gamma = 2.0;                           % m^3 (mmol N)^-1
    gPb = dt*pref*Z*gmax*(1-exp(-gamma*P));

% Holling type III response (sigmoidal)
elseif type == 3
    m = 3;
    gPb = dt*pref*Z*gmax*P^m/(P^m+kP^m);
   
% Holling type IIII response (inhibitory-substrate response)
elseif type == 4
    beta = 0.05;                           % m^3 (mmol N)^-1
    gPb = dt*pref*Z*gmax*P/(kP+P+beta*P^2);
end